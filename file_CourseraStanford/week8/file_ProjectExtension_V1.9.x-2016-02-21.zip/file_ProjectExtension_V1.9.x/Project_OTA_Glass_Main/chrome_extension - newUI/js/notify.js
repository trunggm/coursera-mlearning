//if (typeof jQuery == 'undefined') {
//	openChannel(tokenChannel);
//} else {
//	$(document).ready(function () {
//		openChannel(tokenChannel);
//	});
//}

/*
 * Tao chanel ngay khi tao
 */
initNotificationOHM = function (tokenKey) {
	console.log("function initNotificationOHM chay dau.");
	var tokenUrl = "https://www.ohaymaha.com/api/createChannel";

	$.ajax({
		type: "POST",
	    dataType: "json",
	    url: tokenUrl,
	    headers: {
	    	'E8668OHM' : tokenKey
	    },
	    success:function(data) {
	    	var obj = data;
	    	console.log("create successed!");
	    	if (obj.state == "Ok") {
	    		console.log(obj.tokenChannel);
	    		openChannel(obj.tokenChannel);
	    	} else {
	    		console.log("Can't access tokenChannel");
	    	}
	    },
	    error: function () {
	    	console.log("Connection to " + tokenUrl + " error");
	    }
	});
};

/*
*	Tu  refresh key lay token key ms
*/
initNotificationOHMToken = function () {
	var refreshTokenUrl = "https://user-api.ohaymaha.com/getAccessToken";
	var refreshK;
	var new_TokenKey;
	var new_RefreshKey;
	var refresh_Data;
	var new_Data;
	chrome.cookies.get ({'url': "http://www.ohaymaha.com/",'name':'__ohmr__'}, function (cookiesr) {
		refreshK = cookiesr.value;
		var refreshKey = {refreshToken: refreshK};
		$.ajax({
			type: "POST",
		    contentType: "application/json; charset=utf-8",
		    url: refreshTokenUrl,
		    data: JSON.stringify(refreshKey),
		    success:function(data) {
		    	new_Data = data;
		    	refresh_Data = JSON.stringify(data.token);
		    	console.log("noi dung nhan dc sau khi gui getAccessToken: "+refresh_Data);
		    	console.log("token key ms: "+ JSON.stringify(data.token.tokenKey));
		    	console.log("du lieu tra ve tu initNotificationOHMToken: "+JSON.stringify(new_Data));
		    	new_TokenKey = JSON.stringify(data.token.token);
		    	//initNotificationOHM(JSON.stringify(data.token.tokenKey))
				/*
				*	kiem tra ham setcookies
				*/
				chrome.cookies.set({
					'url': "http://www.ohaymaha.com/",
					'name':'__ohmt__', 
					'value': JSON.stringify(data.token.tokenKey)
					}, 
					function (cookiest){
						console.log("token key ms: "+cookiest.value);
				});	
				chrome.cookies.set({
					'url': "http://www.ohaymaha.com/",
					'name':'__ohmr__', 
					'value': JSON.stringify(data.token.refreshKey)
					}, 
					function (cookiesr){
						console.log("refresh key ms: "+cookiesr.value);
				});
				chrome.runtime.reload();	
		    },
		    error: function(){
		    	console.log(JSON.stringify(refreshKey));
		    	console.log("khong the gui yeu cau den "+refreshTokenUrl+". That bai toan tap.");
		    }
		});
		//console.log("new data tu initNotificationOHMToken: "+refresh_Data);
	});
};



openChannel = function(tokenChannel) {
	channel = new goog.appengine.Channel(tokenChannel);
	socket = channel.open();
	socket.onopen = onSocketOpen;
	socket.onmessage = onSocketMessage;
	socket.onerror = onSocketError;
	socket.onclose = onSocketClose;
};

closeChannel = function () {
	console.log('channel da tu dong close');
	socket.close();
}

onSocketError = function(error){
	console.log('channel error');
	console.log("Error is "+error.description+" and HTML code"+error.code);
	NotificationOHM.onerror();
};

onSocketOpen = function() {
	console.log("Open soccket Success.");

	chrome.tabs.getAllInWindow(null, function(tabs){
		console.log("so luong tabs: "+tabs.length);
	    for (var i = 0; i < tabs.length; i++) {
	    	console.log("tabs "+tabs[i].id+" vs action: socket");
	    	chrome.tabs.sendMessage(tabs[i].id, {action: 'socket'}, function(response) {

	        });
	    }
	});
};

onSocketClose = function() {
	console.log("Socket Connection closed");
	NotificationOHM.onclose();
};

onSocketMessage = function (response) {
	console.log("Notify Message New");
	console.log(response);

	var data = {};
	var obj = JSON.parse(response.data);

	if (obj.type == 1) {
		NotificationOHM.notifyOTA(obj.data);
	} else if (obj.type == 3) {
		NotificationOHM.notifyChatMessage(obj.data);
	} else if (obj.type == 4) {
		NotificationOHM.notifyUserTransaction(obj.data);
	} else if (obj.type == 5) {
		NotificationOHM.notifyUserGetOTA(obj.data);
	} else if (obj.type == 6) {
		NotificationOHM.notifyUserGetKeyword(obj.data);
	} else if (obj.type == 7) {
		NotificationOHM.notifyUserChangeInfor(obj.data);
	} else if (obj.type == 10) {
		NotificationOHM.notifyDeleteNumberNotify(obj.data);
	} else if (obj.type == 20) {
		NotificationOHM.notifyLock(obj.data);
	} else if (obj.type == 999) {
		NotificationOHM.notifySystem(obj.data);
	}
};

var NotificationOHM = {
	onerror : function () {},
	onclose : function () {},
	notifyOTA : function (data) {},
	notifyChatMessage : function (data) {},
	notifyUserTransaction: function (data) {},
	notifyUserChangeInfor: function (data) {},
	notifyUserGetOTA: function (data) {},
	notifyUserGetKeyword: function (data) {},
	notifyDeleteNumberNotify: function (data) {},
	notifyLock: function (data) {},
	notifySystem: function (data) {}
};
