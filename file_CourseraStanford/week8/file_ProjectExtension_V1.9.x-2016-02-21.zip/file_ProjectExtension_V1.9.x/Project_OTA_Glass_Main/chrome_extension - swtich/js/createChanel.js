//load tu file background.html

var count = 0;
var notify = false;
var intNotify = 0;
var	refreshUrl = "https://user-api.ohaymaha.com/getAccessToken";
var new_refreshKey;

// khoi tao chanel khi startup chrom
chrome.cookies.get ({'url': "http://www.ohaymaha.com/",'name':'__ohmt__'}, function (cookies) {
	if (cookies !=null) {
		initNotificationOHM(cookies.value);
		console.log(cookies.value);
		$.ajax({
			    type: "GET",
			    dataType: "json",
			    url: "https://user-api.ohaymaha.com/countnotify",
			    headers: {
			    	'E8668OHM' : cookies.value
			    },
			    success:function(data) {
			    	var obj = data;

			    	if (obj.state == "Ok") {
						var str = "";
						count = obj.count;
						chrome.extension.getBackgroundPage().bnumMessage = count;
						//tao thong bao ra icon hien dang co bao nhieu message chua doc
						if (count > 0) {
							chrome.browserAction.setBadgeText({text: ""+count+""});
							//chrome.browserAction.setBadgeBackgroundColor({ color: '#DF0101' });
						}
					}
			    },
			    error: function () {
			    	console.log("Connection to "+notify+" error");
			    }
		});
	}

	NotificationOHM.notifyClick = function (message) {
	    console.log("Click"+message);
	};

	NotificationOHM.notifySystem = function (message) {
		chrome.notifications.create("OHMEXT"+intNotify, {"title":"Notify from OHM", "iconUrl":"https://lh3.googleusercontent.com/pB6SN6b0Iq9q_ZaVI66wRut1F7_sxJeIQstMHemAjsYx-IsAFdhiJCyO5p-ssx5cZm5lySFs5YNRC14MUoA", "message":message.message, "type": "basic"}, function () {});
	};


	NotificationOHM.notifyOTA = function (message) {
		//tao moi 1 notify khi co message moi
		chrome.notifications.create("OHMEXT"+intNotify, {"title":"Notify from OHM", "iconUrl":message.fromAvatar, "message":message.content, "type": "basic"}, function () {});

		//them su kien click lan dau tien vao notify
		if (notify == false) {
			notify = true;
			chrome.notifications.onClicked.addListener(function (){
				// tao cua so xem full notify
				chrome.windows.getCurrent(function(w) {
						chrome.windows.getAll({}, function (windows) {
							if (windows.length <=1) {
								//neu chua mo cua so thi tao moi
								chrome.windows.create({url:chrome.extension.getURL('html/panel.html'),type:"panel", width:400,height:500,focused: true, left: w.width-400, top: 100});
							} else {
								chrome.windows.update({url:chrome.extension.getURL('html/panel.html'),type:"panel", width:400,height:500,focused: true, left: w.width-400, top: 100});
							}
						});
				})


				//xoa toan bo notify khi nguoi dung click vao 1 message
				chrome.notifications.getAll(function (obj) {
					$.each(obj, function(key, value){
						chrome.notifications.clear(key, function (){});
					});
				});

				//khi dong cua so xem message bien dem message chua doc tro ve 0
				chrome.windows.onRemoved.addListener(function (){
					count = 0;
					//Kien tra
					chrome.storage.sync.get({
							OHMdisable: 'no'
						}, function(items) {
							if( items.OHMdisable =='yes'  ){
								chrome.browserAction.setBadgeText({text: "off"});
								//chrome.browserAction.setBadgeBackgroundColor({ color: '#cccccc' });
							} else {
								chrome.browserAction.setBadgeText({text: "on"});
								//chrome.browserAction.setBadgeBackgroundColor({ color: '#1FD002' });
							}
						}
					);
				});
			});
		}
		intNotify++;
		count ++;
		chrome.extension.getBackgroundPage().bnumMessage = count;

		//tao thong bao ra icon hien dang co bao nhieu message chua doc
		chrome.browserAction.setBadgeText({text: ""+count+""});
		//chrome.browserAction.setBadgeBackgroundColor({ color: '#DF0101' });
	};

	NotificationOHM.onerror = function () {
		$.ajax({
		    url: 'http://ads.ohaymaha.com/logout',
		    type: 'GET',
		    success: function(response){
		    	console.log(response);
		    }
	 	});
	};
 	//nhan json tu khoa tu chanel
	NotificationOHM.notifyUserGetKeyword = function (message) {
		if (typeof message.idBrowser != 'undefined' && chrome.extension.getBackgroundPage().idBrowser == message.idBrowser) {
			  chrome.tabs.sendMessage(parseInt(message.tabId), {message: message, action: "keyword"}, function(response) {

			  });
		}
	};

	//xoa bo so luong notify khi gnuoi dung da doc notify tu cac ung dung khac type=10
	NotificationOHM.notifyDeleteNumberNotify = function (message) {
		count = 0;
		chrome.extension.getBackgroundPage().bnumMessage = 0;
		//Kien tra
		chrome.storage.sync.get({
				OHMdisable: 'no'
			}, function(items) {
				if( items.OHMdisable =='yes'  ){
					chrome.browserAction.setBadgeText({text: "off"});
					//chrome.browserAction.setBadgeBackgroundColor({ color: '#cccccc' });
				} else {
					chrome.browserAction.setBadgeText({text: "on"});
					//chrome.browserAction.setBadgeBackgroundColor({ color: '#1FD002' });
				}
			}
		);
	}
	// khoa de quay thuong
	NotificationOHM.notifyLock = function (message) {
	    console.log(message);
	}
	// tin nhan tu server khi nguoi dung nhan dc OTA
	NotificationOHM.notifyUserGetOTA = function (message) {
		if(chrome.extension.getBackgroundPage().soundStatus == 'on'){
			var myAudio = new Audio();        // create the audio object
			myAudio.src = "../sound/tingting.wav"; // assign the audio file to it
			myAudio.play();
		}
		//chrome.browserAction.setIcon({path: "../img/ohm-off.png"}, function (){});
		//setTimeout({chrome.browserAction.setIcon({path: "../img/icon-exit.png"}, function (){});},1000);
		changeOta (message);
	}


	NotificationOHM.notifyUserChangeInfor = function (message) {
		// code is here
		var obj = message;
		console.log(message);
		var infoMess = obj.info;
		console.log(infoMess);

		var leftsrc = infoMess.lastIndexOf('"avatar":"') + 10;
		var rightsrc = infoMess.lastIndexOf('","ratio');

		var leftfullname = infoMess.lastIndexOf('"fullName":"') + 12;
		var rightfullname = infoMess.lastIndexOf('","currentLocation"');

		console.log(leftsrc);
		console.log(rightsrc);
		chrome.extension.getBackgroundPage().bavatar = 'https:'+infoMess.substring(leftsrc, rightsrc);
		console.log(chrome.extension.getBackgroundPage().bavatar)
		chrome.extension.getBackgroundPage().bfullName = infoMess.substring(leftfullname, rightfullname);
		console.log(chrome.extension.getBackgroundPage().bfullName);
	};

	NotificationOHM.notifyUserTransaction = function (message) {
		changeOta (message);
		//console.log(i);
	};

	/*
	*	khi chanel bi chet, log out khoi extension
	*/
	//neu dong chanel, khoi dong lai chanel
	NotificationOHM.onclose = function () {
		chrome.cookies.get ({'url': "http://www.ohaymaha.com/",'name':'__ohmt__'}, function (cookiesT) {
			if (cookiesT !=null) {
				var tokenKey = cookiesT.value;
				var refreshKey;
	    		chrome.cookies.get ({'url': "http://www.ohaymaha.com/",'name':'__ohmr__'}, function (cookiesR) {
	    			refreshKey = cookiesR.value;
	    			$.ajax({
						type: "POST",
					    dataType: "json",
					    url: refreshUrl,
					    refreshToken: refreshKey,
					    success:function(data) {
					    	var obj = data;
					    	console.log("refresh successed!");
							initNotificationOHM(obj.tokenKey);
							new_refreshKey = obj.refreshKey;
					    },
					    error: function () {
					    	console.log("refresh unsuccessed!");
					    	console.log("Connection to " + tokenUrl + " error");
					    }
					});
	    		});
	    		chrome.cookies.set({'url': "http://www.ohaymaha.com/",'name':'__ohmr__'}, function (cookiesNR){
	    			cookiesNR.value = new_refreshKey;
	    		});
	    	} else {
	    		$.ajax({
				    url: 'http://ads.ohaymaha.com/logout',
				    type: 'GET',
				    success: function(response){
				    	console.log(response);
				    }
			 	});
	    	}
	    });
	};

});

function changeOta (message) {
	tsOTAprize = chrome.extension.getBackgroundPage().bota1;
    tsOTAstore = chrome.extension.getBackgroundPage().bota2;
    tsOTAdeal = chrome.extension.getBackgroundPage().bota3;

    if (typeof message.plusFund !='undefined') {
    	switch( message.plusFund ) {
	        case "1000": {
	        	chrome.extension.getBackgroundPage().bota1 = parseInt(tsOTAprize) + parseInt(message.amountOTA);

	            break;
	        }
	        case "1001": {
	        	chrome.extension.getBackgroundPage().bota2 = parseInt(tsOTAstore) + parseInt(message.amountOTA);
	            break;
	        }
	        case "1002": {
	        	chrome.extension.getBackgroundPage().bota3 = parseInt(tsOTAdeal) + parseInt(message.amountOTA);
	            break;
	        }
	        case "9999": {
	        	chrome.extension.getBackgroundPage().bota1 = 0;
	            break;
	        }
	        default: {

	        }
	    }
		chrome.browserAction.setBadgeText({text: "+" + parseInt(message.amountOTA)});
    }

    if (typeof message.subFund !='undefined') {
    	switch( message.subFund ) {
	        case "1000": {
	        	chrome.extension.getBackgroundPage().bota1 = parseInt(tsOTAprize) - parseInt(message.amountOTA);

	            break;
	        }
	        case "1001": {
	        	chrome.extension.getBackgroundPage().bota2 = parseInt(tsOTAstore) - parseInt(message.amountOTA);
	            break;
	        }
	        case "1002": {
	        	chrome.extension.getBackgroundPage().bota3 = parseInt(tsOTAdeal) - parseInt(message.amountOTA);
	            break;
	        }
	        default: {

	        }
	    }
    }
}
