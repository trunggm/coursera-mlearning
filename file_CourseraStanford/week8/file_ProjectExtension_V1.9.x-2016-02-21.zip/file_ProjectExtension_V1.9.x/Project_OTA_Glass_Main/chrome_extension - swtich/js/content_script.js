//sua cau truc vao ngay 8-5 (ban backup tren drive)
//config

// js thuc hien khi user da login vao ext
var domain = window.location.host;
var flag = safety_zone(domain);
var urlOhm = "https://ads.ohaymaha.com/";
var pubId = 5668411803697152;
var nameOhm = "__ohm__";
var tohm = "__tohm__";
var nameColorOhm = "__color__";
var nameCheckOhm= "__check__";
var clOhm = "FF171F";
var colorOhm = "color:#"+clOhm;
var clLinkOhm = "#1CC56F";
var colorLinkOhm = "color:#"+clLinkOhm;
var numberShowKeyword = 100;
var loginOHM = "http://www.ohaymaha.com/login";
var registerOHM = "http://account.ohaymaha.com/register";
var logoutohm = "http://www.ohaymaha.com/logout";
var ohmObj = {};
var ohmLinkClick = [];
var ohmObjRemove = [];
var objRemove = [];

var languageOhm = $.parseJSON('{"info" : "The OHAYMAHA  extension is used to earn OTA. Please register or log in to OHAYMAHA.","register" : "Register","login" : "Login","infoLogin" : "The OHAY MAHA  extension is used to earn OTA. Please register or log in to OHAY MAHA.","infoLogout" : "B\u1EA1n \u0111ã thoát kh\u1ECFi h\u1EC7 th\u1ED1ng OHM, h\u1EB9n g\u1EB7p l\u1EA1i b\u1EA1n trong th\u1EDDi gian s\u1EDBm nh\u1EA5t.","iconKeyword" : "Keyword","iconColor" : "Color","iconLogout" : "Logout"}');

var statusLoginOhm = "false"; //false: chua login, true: da login

var ohmRegister = "<span class='gotourl' id='infoOhm'>" + languageOhm.info +
		 		"<span class='ohm-browserTooltipBtnWrap'><span onclick='return locations(\""+loginOHM+"\")' class='ohm-browserTooltipBtn'>"+languageOhm.login+"</span>" +
		 				"<span onclick='return locations(\""+registerOHM+"\")' class='ohm-browserTooltipBtn'>"+languageOhm.register+"</span></span></span>";


if( flag ){
 	chrome.storage.sync.get({
	  	OHMdisable: 'no',
	  	color:"#FF171F",
	  	statusLoginOhm: "false",
	  	numberShowKeyword :1
	}, function(keyitems) {
	    if( keyitems.OHMdisable !='yes'  ){
	    	colorOhm = "color:"+keyitems.color;
	    	numberShowKeyword = keyitems.numberShowKeyword;
	    	statusLoginOhm = keyitems.statusLoginOhm;
			extension_main();
		}
	});
}
// if(flag) {
// 	// Gui tin nhan cho bg khi mở tab
// 	var startTime = Date.now();
// 	var tabId;
// 	chrome.extension.sendMessage({ type: 'getTabId' }, function(res) {
// 	    var tabId = res.tabId;
// 	    console.log("gia tri cua tabId la "+tabId);
// 	    chrome.runtime.sendMessage({action: "onunloadPage", url: location.href,  time: startTime, id: tabId}, function(response) {
// 		});
// 	});

// }
//nhan message tu tring duyet
window.addEventListener("message", function (event) {
    // We only accept messages from ourselves
    if (event.source != window) { return; }

    // Make sure we're looking at the correct event:
    if (event.data.type && (event.data.type == "FROM_PAGE")) {
    	console.log(event.data.obj);
    	gotoota(event.data.url, event.data.obj, event.data.ota, event.data.keyword, event.data.tab);
    }
    if (event.data.type && (event.data.type == "LOCATION_PAGE")) {
    	locations(event.data.url);
    }
    if (event.data.type && (event.data.type == "CID_PAGE")) {
    	chrome.runtime.sendMessage({action: "objClick", data: event.data.cId}, function(response) {
  		    //console.log(response.farewell);
    		chrome.tabs.onCreated.addListener(function(tab){
    		    newTabID = tab.id;
    			//alert("new tab "+newTabID);
    			setTimeout(function(){chrome.tabs.remove(newTabID);}, 1000);
    		});
  		});
    }

}, false);

function extractDomain(url) {
    var domain;
    //find & remove protocol (http, ftp, etc.) and get domain
    if (url.indexOf("://") > -1) {
        domain = url.split('/')[2];
    }
    else {
        domain = url.split('/')[0];
    }

    //find & remove port number
    domain = domain.split(':')[0];

    return domain;
}

//nhan message tu popup

// chon OTA khi da dang nhap
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
	//chon tu khoa tu notify: edit keywords->keyword
	//{"message":"{\"type\":6,\"time\":1433401864650,\"data\":{\"selector\":\"body\",\"username\":\"chinhvd\",\"status\":\"0\",\"keyword\":{\"Dự án\":[{\"name\":\"TECHCOMBANK\",\"ota\":3,\"url\":\"http://ads.ohaymaha.com/click?c\u003dc894ede8f1c59e47b80134d18adc2ba4bwiwgm\"},{\"name\":\"EDITION\",\"ota\":2,\"url\":\"http://ads.ohaymaha.com/click?c\u003da2b798b4590a9add8bb9ee58df6a1f98bwiwgm\"}],\"tiền\":[{\"name\":\"TECHCOMBANK\",\"ota\":3,\"url\":\"http://ads.ohaymaha.com/click?c\u003d85597a5f2ce3dbea99bba47f1a047d4ebwiwgm\"}],\"Samsung\":[{\"name\":\"SAMSUNG\",\"ota\":2,\"url\":\"http://ads.ohaymaha.com/click?c\u003d99ac35e5484cf7b437d9c1cafa74ab6abwiwgm\"}]},\"state\":\"Ok\",\"avatar\":\"//lh3.googleusercontent.com/WPALGJQnw4ZiiEWusiT4M-h939axiFnNUmMKWtr0z2cJbZD4x_lGoOut53RCIg7zjNhDCEG3Dp_XMDzMEKP9\",\"lang\":\"vi\",\"url\":{}}}","userId":"870"}
	//http://www.ohaymaha.com/api/sendChannelMessage
	var OHMdomain = document.domain;
	// kiem tra domain ohaymaha.com
	if(OHMdomain.search("ohaymaha.com")===-1){
		if (request.action == "keyword") {
			checkNumberShowKeyword = {};
			// gui yeu cau nhan keyword
			var obj = request.message ;
			console.log(obj);
			var select = obj.select;
			/*.ohm-browserLinkHighlights {     color: #1CC56F!important}*/
			$("body").append('<style id="ohm-style">#ohm-browserTooltip *, .ohm-browserKeywordHighlights { background: 0 0!important; border: none!important; box-shadow: none!important; text-decoration: none!important; cursor: pointer!important; height: auto!important; float: none!important; margin: 0!important; padding: 0!important } .ohm-imgLinkHighlights:before { content: url(https://storage.googleapis.com/ohm-account-md/v1/ohm_coin_40.png); position: absolute; } .ohm-browserLinkHighlights { color: #1CC56F!important; } .ohm-browserLinkHighlights:hover { -ms-transform: scale(1.2, 1.2)!important; -webkit-transform: scale(1.2, 1.2)!important; transform: scale(1.2, 1.2)!important; } .ohm-browserKeywordHighlights { overflow: visible!important; font-size: inherit!important; width: auto!important; left: 0!important; top: 0!important; right: 0!important; bottom: 0!important; display: inline!important; position: relative!important; opacity: initial!important; z-index: 99; } #ohm-browserTooltip #infoOhm, #ohm-browserTooltip * { line-height: 20px!important; font-size: 13px!important; } #ohm-browserTooltip { width: 300px!important; z-index: 9999999999!important; background: #fff!important; position: absolute!important; border: 1px solid #fff!important; box-shadow: 0 1px 6px rgba(0, 0, 0, 0.12), 0 1px 6px rgba(0, 0, 0, 0.12)!important; } #ohm-browserTooltip * { opacity: 1!important; visibility: visible!important; color: #333!important; font-weight: 400!important; font-style: normal!important; letter-spacing: normal!important; font-family: arial!important; display: block!important; text-indent: inherit!important; position: static!important; } #ohm-browserTooltip .tooltip-oat-ohm-text { border-bottom: 1px solid #eee !important; } #ohm-browserTooltip .ohm-hightlightAdv .tooltip-oat-ohm-text, #ohm-browserTooltip .tooltip-oat-ohm-text_inner { position: relative !important; } #ohm-browserTooltip .tooltip-oat-ohm-text .ohm-advDesc { position: absolute !important; right: 5px !important; top: 5px !important; background: #fff !important; width: 80% !important; z-index: 1; box-shadow: 0px 0px 3px #D0D0D0 !important; padding: 25px 10px 10px 10px !important; box-sizing: border-box !important; } #ohm-browserTooltip .tooltip-oat-ohm-text .ohm-advDesc img { position: absolute !important; right: 5px !important; width: 18px !important; top: 6px; opacity: .6 !important; } #ohm-browserTooltip .tooltip-oat-ohm-text .ohm-advDesc .ohm-bn { font-size: 14px !important; margin-bottom: 6px !important; font-weight: 700 !important; color: #2582DE !important; text-decoration: underline !important; } #ohm-browserTooltip .tooltip-oat-ohm-text .ohm-more { position: absolute !important; right: 2px !important; line-height: 100% !important; bottom: 15px !important; padding: 3px 6px !important; border-radius: 50% !important; font-size: 10px !important; top: -2px !important; text-decoration: underline !important; color: #838486 !important; opacity: .65 !important; height: 18px !important; } #ohm-browserTooltip .tooltip-oat-ohm-text .ohm-more:hover { opacity: 1 !important; } #ohm-browserTooltip .tooltip-oat-ohm-text .ohm-more img { width: 18px !important; } #ohm-browserTooltip .ohm-gotourl { white-space: nowrap!important; position: relative!important; border-bottom: 1px solid rgba(255, 255, 255, .17)!important; padding: 15px 65px 15px 10px!important; } #ohm-browserTooltip .tooltip-oat-ohm-text:hover, #ohm-browserTooltip .tooltip-oat-ohm-text:hover * { background: #fff!important; color: #424242!important; } #ohm-browserTooltip .ohm-disabled *, #ohm-browserTooltip.ohm-browserLink .ohm-disabled { color: rgba(255, 255, 255, .46)!important; } #ohm-browserTooltip .ohm-disabled:hover, #ohm-browserTooltip .ohm-disabled:hover * { cursor: no-drop!important; } #ohm-browserTooltip .ohm-gotourl .ohm-keyword, #ohm-browserTooltip .ohm-gotourl .ohm-keyword>a { overflow: hidden!important; text-overflow: ellipsis!important; text-align: left!important; max-width: 175px; font-size: 15px !important; margin: 3px 0 6px 0 !important; line-height: 100% !important; } #ohm-browserTooltip .ohm-gotourl .ohm-keyword>a span { display: inline!important; } #ohm-browserTooltip .ohm-gotourl .ohm-timeOnSite { color: #9A9A9A !important; margin-top: 2px !important; font-size: 12px !important; line-height: 100% !important; } #ohm-browserTooltip .ohm-gotourl .ohm-plusota { position: absolute!important; right: 10px!important; top: 50%!important; margin-top: -10px !important; font-size: 20px !important; font-weight: bold !important; color: #FF7A00 !important; } #ohm-browserTooltip .ohm-gotourl .ohm-plusota img, #ohm-browserTooltip .ohm-linkText img { height: 16px!important; vertical-align: middle!important; position: relative!important; top: -2px!important; margin: 0!important; display: inline-block!important; } #ohm-browserTooltip .ohm-advBrand { width: 40px !important; margin-right: 10px !important; } #ohm-browserTooltip .ohm-browserTooltipBtnWrap { text-align: right!important; } #ohm-browserTooltip .ohm-browserTooltipBtn { padding: 16px!important; text-transform: uppercase!important; display: inline-block!important; font-weight: 500!important; } #ohm-browserTooltip #infoOhm { padding: 10px 10px 0!important; } #ohm-browserTooltip.ohm-browserLink { max-width: 90px!important; width: auto!important; } #ohm-browserTooltip .ohm-linkText { text-align: center!important; padding: 10px!important; line-height: 100%!important; } #ohm-browserTooltip .ohm-linkText img { width: 15px!important; } #ohm-browserTooltip .ohm-showMore { padding: 8px !important; } #ohm-browserTooltip .ohm-showMore img { width: 20px !important; margin: 0 auto !important; } #ohm-browserTooltip .ohm-showMore:hover { color: #fff!important; } #ohm-browserTooltip .ohm-otherAdv { background: #fff!important; } #ohm-browserTooltip .ohm-arrow { text-align: center!important; padding: 3px 0!important; background: #F9F9F9!important; border-bottom: 1px solid #ECECEC!important; } #ohm-browserTooltip .ohm-arrow.ohm-btnDisabled span, #ohm-browserTooltip .ohm-arrow.ohm-btnDisabled:hover span { color: #0070C1!important; } #ohm-browserTooltip .ohm-arrow span { display: inline-block!important; font-size: 20px!important; color: #848484!important; } #ohm-browserTooltip .ohm-actived .ohm-plusota, #ohm-browserTooltip .ohm-hidden, #ohm-browserTooltip.ohm-hidden { display: none!important; } #ohm-browserTooltip .ohm-arrow:hover span { color: #5F5F5F!important; } #ohm-browserTooltip .ohm-arrowUp span { -ms-transform: rotate(90deg); -webkit-transform: rotate(90deg); transform: rotate(90deg); } #ohm-browserTooltip .ohm-arrowDown span { -ms-transform: rotate(-90deg); -webkit-transform: rotate(-90deg); transform: rotate(-90deg); } #ohm-browserTooltip .ohm-viewport { max-height: 204px; overflow: hidden; } #ohm-browserTooltip .ohm-actived { background: #A9A9A9!important; } #ohm-browserTooltip .ohm-actived * { color: #333!important; } #ohm-browserTooltip .ohm-actived .ohm-gotourl { padding: 10px!important; } #ohm-browserTooltip .ohmRow { box-sizing: border-box!important; display: -webkit-flex!important; display: -moz-flex!important; display: -ms-flexbox!important; display: flex!important; } #ohm-browserTooltip .ohm-kwfsr { -webkit-flex-shrink: 0!important; flex-shrink: 0!important; } #ohm-browserTooltip .ohm-kwfg { -webkit-flex-grow: 1!important; flex-grow: 1!important; } #ohm-browserTooltip .ohm-kwverticalCenter { -ms-flex-align: center!important; -webkit-align-items: center!important; -webkit-box-align: center!important; align-items: center!important; } #ohm-browserTooltip .tooltip-oat-ohm-text .tooltip-oat-ohm-text_inner .ohm-advDesc { display: none!important; }</style>');
			//$('body').append("<div id = \"sound\"> <embed src=\""+"../sound/sound.mp3"+"\" hidden=\"true\" autostart=\"true\" loop=\"false\" /></div>")

			var selector = obj.selector;
			var text = $(selector).html();
			var domain = window.location.host;

			if (typeof obj.username != 'undefined') {
				statusLoginOhm = 'true';
			}

			if(statusLoginOhm == "true") {
				$("#avatarOhm").html("<img style='border-radius:30px;-moz-border-radius:30px;-webkit-border-radius:30px;border:3px solid while;' src='"+obj.avatar+"'>");
				$("#usernameOhm").html("<a href='http://account.ohaymaha.com/userinfo' target='_blank'>"+obj.username+"</a>");
			}

			if (statusLoginOhm == "true") {
				$.each( obj.url, function( key, val ) {
					var keys = key;
				  	$('body a').each(function() {
				  		var hr = qualifyURL ($(this).attr("href")).replace(/[\/]+$/i,"");
				  		if (extractDomain(hr) == "www.amazon.com") {
							hr = hr.replace(/\/ref=[\w\W]+/g, "");

						}
				  		if ( typeof $(this).attr("href") !== "undefined" && key == hr ) {
				  			var textHTML=$(this).html();
				  			if (textHTML.substring(0,4)=="<img" ) {
				  				$(this).addClass("ohm-imgLinkHighlights");
				  			}
			  				$(this).attr("onclick","return gotoota(\""+val[0].url+"\", this.id, "+val[0].ota+", \""+keys.toLowerCase()+"\", \"currentTab\")");
			  				$(this).attr("data", val[0].ota);
			  				$(this).attr("cid", val[0].cId);
			  				$(this).addClass("ohm-browserLinkHighlights");
			  				$(this).css("color", clLinkOhm);
			  				var textParent = this.parentElement.parentNode;
			  				console.log(textParent);
				  		}
					});

				  	// gui ve source anh
				  	$('body img').each(function() {
				  		var src = qualifyURL ($(this).attr("src")).replace(/[\/]+$/i,"");
				  		var test1 = $(this).attr("src");

				  		if ( typeof $(this).attr("src") !== "undefined" && key == src ) {
				  			// thuc hien chon OTA vao anh o day.
				  			console.log(test1);
				  			$(this).parent().addClass("ohm-imgLinkHighlights");
				  			$(this).parent().attr("onclick","return gotoota(\""+val[0].url+"\", this.id, "+val[0].ota+", \""+keys.toLowerCase()+"\", \"currentTab\")");
			  				$(this).parent().attr("data", val[0].ota);
			  				$(this).parent().attr("cid", val[0].cId);
			  				$(this).parent().addClass("ohm-browserLinkHighlights");
				  		}
					});
				});
			}

			var ohmSortKey = sortObject(obj.keyword);

			var keySave;

			if (typeof select == 'undefined') {
				var objectOHM = $(selector);
			} else {
				var   objectOHM = $(select);
			}
			if (objectOHM.length <= 0) {
				objectOHM = $('body');
			}

			objectOHM.each(function() {
	var abc = this;
	$.each( ohmSortKey, function( key, val ) {
		var ohmValue = "";
		var valohm = val.length;
		var descohm = val.des;
		keySave = key;
		var ct = 0;
		var waittime;
		$.each( val, function( key, val ) {
//					ohmValue = ohmValue +"<span class='tooltip-oat-ohm-text' title='"+val.name+"'><span data='"+val.cId+"' id='ohmblock"+kohm+"' class='ohm-gotourl ohm"+val.cId+"' onclick='return gotoota(\""+val.url+"\", this.id, "+val.ota+", \""+keySave.toLowerCase()+"\", \"newTab\");' ><span class='ohm-keyword'> "+smartTrim(val.name, 30," ", " ...")+"</span> <span class='ohm-plusota'>+ "+val.ota+" <img src='"+urlOhm+"images/dtohm.png' /></span></span></span>";
			waittime = val.timeCondition;
			if(waittime < 0){
				waittime = 0;
			}
			var imo = val.logo;
			if (imo == "") {
				imo = "https://storage.googleapis.com/ohm-account-md/v1/ohm-face.png";
			}
			if (ct <=1) {
				if(ct == 0)
					ohmValue = ohmValue + "<div class='ohm-hightlightAdv'>";
				ohmValue = ohmValue + '<span class="tooltip-oat-ohm-text">'
											+'<span class="tooltip-oat-ohm-text_inner">'
												+"<a href=\""+val.url+"\" target=\"_blank\"data='"+val.cId+"' id='ohmblock"+kohm+"' class='ohm-gotourl ohm"+val.cId+"' onclick='return gotoota(\""+val.url+"\", this.id, "+val.ota+", \""+keySave.toLowerCase()+"\", \"newTab\");'>"													+'<span class="ohmRow ohm-kwverticalCenter">'
														+'<span class="ohm-kwfsr">'
															+'<img class="ohm-advBrand" src="'+imo+'" alt="">'
														+'</span>'
														+'<span class="ohm-kwfg">'
															+'<span class="ohm-keyword">'+smartTrim(val.name, 30," ", " ...")+'</span>'
															+'<span class="ohm-timeOnSite">'
																+'Freeze time : '+waittime+'s'
															+'</span>'
														+'</span>'
													+'</span>'
													+'<span class="ohm-plusota">+'+val.ota+' ' +'<img src="https://ads.ohm.vn/images/dtohm.png"></span>'
												+'</a>'
												+'<span class="ohm-more"><img src="https://storage.googleapis.com/ohm-images/extension/icon-more.png"></span>'
												+'<span class="ohm-advDesc" >'
													+'<img src="https://storage.googleapis.com/ohm-images/extension/icon-close.png" alt="">'
													+'<span class="ohm-bn">'+smartTrim(val.name, 30," ", " ...")+'</span>'
													+val.des
												+'</span>'
											+'</span>'
										+'</span>';
} else {
				if (ct == 3) {
					ohmValue = ohmValue + "</div>";
					ohmValue = ohmValue + "<div class='ohm-showMore'><img src='https://storage.googleapis.com/ohm-images/extension/icon-more.png'></div>";
				ohmValue = ohmValue 	+ "<div class='ohm-otherAdv ohm-hidden'>"
											+"<div class='ohm-arrowUp ohm-arrow'>"
												+"<span>&lsaquo;</span>"
											+"</div>"
											+"<div class='ohm-viewport'>"
												+"<div class='ohm-viewport_inner'>";
			}
				ohmValue = ohmValue +  '<span class="tooltip-oat-ohm-text">'
											+'<span class="tooltip-oat-ohm-text_inner">'
												+"<a href=\""+val.url+"\" target=\"_blank\"data='"+val.cId+"' id='ohmblock"+kohm+"' class='ohm-gotourl ohm"+val.cId+"' onclick='return gotoota(\""+val.url+"\", this.id, "+val.ota+", \""+keySave.toLowerCase()+"\", \"newTab\");'>"													+'<span class="ohmRow ohm-kwverticalCenter">'
													+'<span class="ohmRow ohm-kwverticalCenter">'
														+'<span class="ohm-kwfsr">'
															+'<img class="ohm-advBrand" src="'+imo+'" alt="">'
														+'</span>'
														+'<span class="ohm-kwfg">'
															+'<span class="ohm-keyword">'+smartTrim(val.name, 30," ", " ...")+'</span>'
															+'<span class="ohm-timeOnSite">'
																+'Freeze time : '+waittime+'s'
															+'</span>'
														+'</span>'
													+'</span>'
													+'<span class="ohm-plusota">+'+val.ota+' '+ '<img src="https://ads.ohm.vn/images/dtohm.png"></span>'
												+'</a>'
												+'<span class="ohm-more"><img src="https://storage.googleapis.com/ohm-images/extension/icon-more.png" alt=""></span>'
												+'<span class="ohm-advDesc">'
													+'<img src="https://storage.googleapis.com/ohm-images/extension/icon-close.png" alt="">'
													+'<span class="ohm-bn">'+smartTrim(val.name, 30," ", " ...")+'</span>'
													+val.des
												+'</span>'
											+'</span>'
										+'</span>';
}

			if (ct == (valohm - 1) && ct >=3) {
				ohmValue = ohmValue + "</div></div><div class='ohm-arrowDown ohm-arrow'><span>&lsaquo;</span></div></div>";
			}
			if (ct == (valohm - 1) && ct <3) {
				ohmValue = ohmValue + "</div>";
			}
			kohm++;
			ct++;
			});

					ohmObj[$.trim(key)] = ohmValue;

					var pattern = "([\(\)\"“”.,?:;!#$%\t\n\v\f\r\) ]{1})("+key+")([\(\)\"“”.,?:;!#$%\t\n\v\f\r\) ]{1})";

					guessLanguage.info(key, function(info) {
					    //console.log('Detected Language: ' + info[2] + " [" + info[0] + "]");
					    if (info[0] == "zh" || info[0] == "ja" || info[0] == "ko") {
					    	pattern = "([\(\)\"“”.,?:;!#$%\t\n\v\f\r\) ]{0,1})("+key+")([\(\)\"“”.,?:;!#$%\t\n\v\f\r\) ]{0,1})";
					    }
					});

					if (numberShowKeyword != 100)
						var exps = new RegExp(pattern, "");
					else
						var exps = new RegExp(pattern, "g");
					traverseChildNodes(abc, exps);
				});
			});

			ohmToolTip ();
	    }
		/*
		*
		*/
		//thay doi mau sac thay action changeColor = changeKeyColor
	    if (request.action == "changeKeyColor") {
	    	if (!checkIsPublisher()) {
		    	$(".ohm-browserKeywordHighlights").css("cssText", "color: "+request.color+" !important;");
		    	colorOhm = "color:"+request.color;

	    	}
	    }
	    // thay doi mau sac cua link doi changeColor thanh changeLinkColor
	    if (request.action == "changeLinkColor") {
	    	if (!checkIsPublisher()) {
	    		//console.log("Change Link color");
		    	$(".ohm-browserLinkHighlights").css("cssText", "color: "+request.color+" !important;");
		    	colorLinkOhm = "color:"+request.color;
		    	clLinkOhm = request.color;
		    	//console.log(request.color);
	    	}
	    }

	    //khi logout
	    if (request.action == "logout") {
	    	console.log("log out");
	    	$(".ota-ohm").contents().unwrap();
	    	statusLoginOhm = "false";
	    	chrome.storage.sync.set({'statusLoginOhm': "false"}, function() {});
	    	$(".ohm-browserLinkHighlights").each(function(){
	    		$(this).removeClass("ohm-browserLinkHighlights");
	    		$(this).removeClass("ohm-imgLinkHighlights");
	    		$(this).unbind("click");
	    		$(this).unbind("mouseenter");
	    		$(this).attr("onclick", "");
	    	});
	    	$(function(){
		    	if (checkIsPublisher()) {
		    		window.location = location.href;
		    	}
	    	});
	    }

	    //khi login (nhan message tu background)
	    if (request.action == "login" || request.action == "numberShowKeyword") {
	    	$(function(){
		    	chrome.storage.sync.get({
		    	  	OHMdisable: 'no',
		    	  	color:"#FF171F",
		    	  	numberShowKeyword : 1
		    	}, function(keyitems) {
		    		statusLoginOhm = "true";
		    		chrome.storage.sync.set({'statusLoginOhm': "true"}, function() {});
		    	   	if( keyitems.OHMdisable !='yes'  ){
		    	    	$(".ota-ohm").contents().unwrap();
		    	    	$(".ohm-browserKeywordHighlights").contents().unwrap();
		    	    	colorOhm = "color:"+keyitems.color;
		    	    	numberShowKeyword = keyitems.numberShowKeyword;
		    	    	keyword();
		    		}
		    	});
	    	});
	    }

	    if (request.action == "socket") {
	    	console.log("socket");
	    	chrome.storage.sync.get({
	    	  	OHMdisable: 'no',
	    	  	color:"#FF171F",
	    	  	numberShowKeyword : 1
	    	}, function(keyitems) {
	    		statusLoginOhm = "true";
	    		chrome.storage.sync.set({'statusLoginOhm': "true"}, function() {});
	    	    if( keyitems.OHMdisable !='yes'  ){
	    	    	if (!checkIsPublisher()) {
		    	    	$(".ota-ohm").contents().unwrap();
		    	    	$(".ohm-browserKeywordHighlights").contents().unwrap();
		    	    	colorOhm = "color:"+keyitems.color;
		    	    	numberShowKeyword = keyitems.numberShowKeyword;

		    	    	keyword();
	    	    	}
	    		}
	    	});
	    }
	    //request tu da click
	    if (request.action == "objRemove") {
	    	if(request.eltObj) {
	    		objRemove = request.eltObj;
	    	}
	    	if (checkIsPublisher()){
	    		if (statusLoginOhm == "true") {
	    			$(".ohm-browserKeywordHighlights").hover(function(){
			    		if(objRemove.length > 0) {
							$.each(objRemove, function(key, val){
								// htmlTooltip = htmlTooltip.replace("ohm"+val, "ohm-disabled");
								if($('#ohm-browserTooltip .ohm'+val)){
									$('#ohm-browserTooltip .ohm'+val).addClass('ohm-disabled');
								}
							});
						}
			    	});
			    	$(".ohm-browserLinkHighlights").hover(function(){
			    		if(objRemove.length > 0) {
							$.each(objRemove, function(key, val){
								// htmlTooltip = htmlTooltip.replace("ohm"+val, "ohm-disabled");
								if($('#ohm-browserTooltip .ohm'+val)){
									$('#ohm-browserTooltip .ohm'+val).addClass('ohm-disabled');
								}
							});
						}
			    	});
				}
	    	}
	    }
	    //thay doi trang thai cua kinh
	    if (request.action == "changeStatus") {
	    	console.log("changeStatus");
	    	if (!checkIsPublisher()) {
		    	if (request.status == "on") {
		    		chrome.storage.sync.get({
		        	  	OHMdisable: 'no',
		        	  	color:"#FF171F",
		        	  	numberShowKeyword : 1
		        	}, function(keyitems) {
		        	    if( keyitems.OHMdisable !='yes'  ){
		        	    	/*if(request.token != "undefined" || request.token != '') {
		        	    		statusLoginOhm = "true";
		        	    	} else {
		        	    		statusLoginOhm = "false";
		        	    	}*/
		        	    	colorOhm = "color:"+keyitems.color;
		        	    	numberShowKeyword = keyitems.numberShowKeyword;
		        	    	keyword();
		        		}
		        	});

		    	} else {
		    		console.log('OTA offf');
		    		$(".ohm-browserKeywordHighlights").contents().unwrap();
		    		$(".ota-ohm").contents().unwrap();
		    		$(".ohm-browserLinkHighlights").each(function(){
		    			$(this).removeClass("ohm-imgLinkHighlights");
			    		$(this).removeClass("ohm-browserLinkHighlights");
			    		$(this).unbind("click");



			    		$(this).unbind("mouseenter");
			    		$(this).attr("onclick", "");
			    		$(this).attr("data", "")
			    	});
		    	}
	    	}
	    }

	}
});

function extension_main(){
    console.log('OTA Glass');

    //goi ham tu client vao content
    var head = document.getElementsByTagName("head")[0];
    fn = 'function gotoota(url, obj, ota, keyword, tab) {window.postMessage({type: "FROM_PAGE",url: url, obj:obj, ota:ota, keyword:keyword, tab:tab}, "*"); } '+
    	 'function locations(url) {window.postMessage({type: "LOCATION_PAGE", url: url}, "*"); }';

    var script = document.createElement('script');
    script.setAttribute("type", "application/javascript");
    script.textContent = fn;
    head.appendChild(script);

    $(function(){

		 chrome.storage.sync.get({
       	  	OHMdisable: 'no',
       	  	color:"#FF171F",
       	  	numberShowKeyword : 1
       	}, function(keyitems) {
       	    if( keyitems.OHMdisable !='yes'  ){
       	    	var loc = location.href;
       	    	var title = $("title").text();
       	    	var change = false;
       	    	setInterval(function(){
       	    		//kiem tra viec thay doi url
       	    		if (loc != location.href) {
   	    				loc = location.href;
   	    				change = true; //thay doi bien dam bao trang thai thay doi url
       	    		}

	    			if (change) {
       	    			if($("body #ires").length) {
					         setTimeout(function(){ keyword(); change = false;  },1000);
					    } else {
					    	//neu thay doi title: nghia la dom la load thanh cong
		       	     		if (title != $("title").text() && change) {
		       	     			//chon tu khoa va thay doi trang thai bien change url
		       	     			setTimeout(function(){ keyword(); change = false;  },1000)
			    			}
					    }
	    			}

       	    	}, 1000);
       	    	console.log("refress page");
       	    	keyword();
       		}
       	});
	 });
}

var startTime = Date.now();
function keyword() {
	// Gui tin nhan cho bg khi mở tab
	var tabId;
	chrome.extension.sendMessage({ type: 'getTabId' }, function(res) {
	    var tabId = res.tabId;
	    chrome.runtime.sendMessage({action: "onunloadPage", url: location.href,  time: startTime, id: tabId}, function(response) {
		});
	    //setTimeout(function(){chrome.tabs.remove(newTabID); console.log('you clicked!');}, 1000);

	});
	if (!checkIsPublisher()){
		if (statusLoginOhm != "true") {
			console.log("No login")
			loadKeyword();
		} else {
			console.log("Login");
			setTimeout(function(){
				console.log("Send message");
				chrome.runtime.sendMessage({action: "keyword", content: $("body").html(), url: location.href}, function(response) {
	//	  		    console.log(response.farewell);
		  		});
			},1000);
		}
	}
}

function checkIsPublisher() {
	if ($("script").text().indexOf("var pubId = ") != -1){
		return true;
	}
	return false;
}
function safety_zone(domain){

    return true;
}
