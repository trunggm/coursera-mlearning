

var request = "https://ads.ohm.vn/after-click?utm_session=";
var urlTab = window.location.href();
var myAudio = new Audio();        // create the audio object
myAudio.src = "https://storage.googleapis.com/ohm-sound/sound.mp3"; // assign the audio file to it


/*
 * function count down
 */
var seconds;
var temp;
//var OHMdomain = window.location.href();
/*
$('body p').prepend("<a href=\"https:facebook.com\">haha</a>")
*/
function getParameter(theParameter) { 
	  var params = window. location .search.substr(1).split('&');
	 
	  for (var i = 0; i < params.length; i++) {
	    var p=params[i].split('=');
		if (p[0] == theParameter) {
		  return decodeURIComponent(p[1]);
		}
	  }
	  return false;
}


// mo tab moi bang js de chay den trang quang cao
//function requestJS(urlrequest){
//	var newtab = window.open(urlrequest, 'blank');
//	//newtab.close();
//}
/*
* ha sach cua monato
*/
//var urlTab = location.href;
//console.log(urlTab);
///

var otaVal;
if(urlTab.lastIndexOf("utm_tc")){		
	otaVal = getParameter('utm_val');
}

// gui request thong bao nguoi dung da cho du thoi gian by ajax
function requestURL(urlrequest){
	$.ajax({
		url: urlrequest,
		type: "GET"
	});
}

/*
 *  FUNCTION COUNTDOWN()	
 */
function countdown() {
	  seconds = document.getElementById('countdown').innerHTML;
	  seconds = parseInt(seconds, 10);

	  if (seconds < 1) {
			    temp = document.getElementById("Successed");
			    //myAudio.play();
			    temp.innerHTML = "Congratulation! You earned " + otaVal +" OTAs";
			    requestURL(request);
			    $("body").removeClass("padding");
			    setTimeout(function(){$("#ohm-countdownBar").remove();}, 1000);
			    console.log('end time');
			    return;
	  }

	  seconds-=1;
	  temp = document.getElementById('countdown');
	  temp.innerHTML = seconds;
	  timeoutMyOswego = setTimeout(countdown, 1000);
}




/*
 *  Thuc hien them noi dung khi dem file	
 */
$(document).ready(function(){
	console.log("vao trang quang cao!");
	if(urlTab.lastIndexOf('utm_source')!=-1){
		var timeIdx = getParameter('utm_tc');
		console.log("Bat trang quang cao");	
		if(parseInt(timeIdx) >=1){
			var waitTime = getParameter('utm_tc');
			console.log(getParameter("utm_keyword"));
			var waitTimeIdx = parseInt(waitTime, 10);
			//otaVal = getParameter('utm_val');
			if(waitTimeIdx>0){		
				request += getParameter('utm_session');
				console.log(waitTime + request);
				$("body").addClass("padding");
				$("body").prepend("<div id='ohm-countdownBar'> <img src='https://storage.googleapis.com/ohm-account-md/v1/logo.png' alt=''/> <span class='ohm-text' id = 'Successed'>To earn full OTA, please wait in: "+"<span id='countdown'>"+waitTime+"</span>"+" Second</span> </div>");
				countdown();
			}
		}
		/*
		else{
			myAudio.play();
		}*/
	};
});
