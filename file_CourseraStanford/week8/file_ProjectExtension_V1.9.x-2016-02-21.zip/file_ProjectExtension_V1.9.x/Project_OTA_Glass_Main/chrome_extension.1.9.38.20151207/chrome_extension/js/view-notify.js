var notify = "https://user-api.ohm.vn/listnotify";
var tokenKey;
chrome.cookies.get ({'url': "http://www.ohm.vn/",'name':'__ohmt__'}, function (cookies) {
	if (cookies != null) {
		tokenKey = cookies.value;
	}	
	
	var obj = {page:1, row: 30};

	$.ajax({
		    type: "POST",
		    dataType: "json",
		    url: notify,
		    data: JSON.stringify(obj),
		    headers: {
		    	'E8668OHM' : tokenKey
		    },
		    success:function(data) { 
		    	var obj = data;	
			
		    	if (obj.state == "Ok") {	
				var str = "";
				var list = obj.list;


				$.each( list, function( key, val ) {	
					var date = new Date(val.time);
					str += "<tr><td><img width='60' src='"+val.avatar+"'/></td><td>"+val.title+"<br/>"+
					date.getHours()+":"+date.getMinutes()+":"+date.getSeconds()+" "+date.getDay()+"-"+date.getMonth()+"-"+date.getFullYear()+"</td></tr>"
				});
				$("#notify").html(str);
			}
		    },
		    error: function () {
		    	console.log("Connection to "+notify+" error");
		    }
	});
});
