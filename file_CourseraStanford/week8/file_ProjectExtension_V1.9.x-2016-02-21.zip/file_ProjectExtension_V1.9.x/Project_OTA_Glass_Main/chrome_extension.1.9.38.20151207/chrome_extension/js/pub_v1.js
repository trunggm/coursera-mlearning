// js action when user not login
////////////////////////////////
function smartTrim(str, length, delim, appendix) {
    if (str.length <= length) return str;

    var trimmedStr = str.substr(0, length+delim.length);

    var lastDelimIndex = trimmedStr.lastIndexOf(delim);
    if (lastDelimIndex >= 0) trimmedStr = trimmedStr.substr(0, lastDelimIndex);

    if (trimmedStr) trimmedStr += appendix;
    return trimmedStr;
}
	  
function sortObject(o) {
    var sorted = {},
    key, a = [];

    for (key in o) {
    	if (o.hasOwnProperty(key)) {
    		a.push(key);
    	}
    }

    a.sort(function(a, b){
    	  return b.length - a.length;
    });

    for (key = 0; key < a.length; key++) {
    	sorted[a[key]] = o[a[key]];
    }
    return sorted;
}

//ie queryselector all
if (!document.querySelectorAll) {
	document.querySelectorAll = function (selectors) {
		var style = document.createElement('style'), elements = [], element;
		document.documentElement.firstChild.appendChild(style);
		document._qsa = [];
	 
		style.styleSheet.cssText = selectors + '{x-qsa:expression(document._qsa && document._qsa.push(this))}';
		window.scrollBy(0, 0);
		style.parentNode.removeChild(style);
		 
		while (document._qsa.length) {
			element = document._qsa.shift();
			element.style.removeAttribute('x-qsa');
			elements.push(element);
		}
		document._qsa = null;
		return elements;
	};
} 

function decodeHtml(html) {
    var txt = document.createElement("textarea");
    txt.innerHTML = html;
    return txt.value;
}
var checkNumberShowKeyword = {};
function traverseChildNodes(node, exp) {
	var next;
	if (node.nodeType === 1) {
		if (node = node.firstChild) {
			do {
				next = node.nextSibling;
				traverseChildNodes(node, exp);
			} while (node = next);
		}
	} else if (node.nodeType === 3) {
		var text = " "+decodeHtml(node.data)+" ";
		if (text.match(exp)) {
			if (typeof checkNumberShowKeyword[exp] == 'undefined') {
				checkNumberShowKeyword[exp] = 1;
			} else {
				checkNumberShowKeyword[exp] += 1;
			}
			if (typeof checkNumberShowKeyword[exp] != 'undefined' && checkNumberShowKeyword[exp] <= numberShowKeyword) {
				wrapMatchesInNode(node, exp);
			}
		}
	}
}

var checkAppendNode = false;

function wrapMatchesInNode(textNode, exp) {
	//neu la facebook
	if (typeof $(".conversation").attr('class') != 'undefined') {
		if (textNode.parentNode.className != "ohm-browserKeywordHighlights") {
			checkAppendNode = false;
			var temp = document.createElement('div');
			var text = decodeHtml(" "+textNode.data+" "); 
			
			if (text.indexOf('<meta') == -1) {
				if (typeof clOhm == "undefined")
					colorOhm = "color:#FF171F";
				temp.innerHTML = text.replace(exp,"$1<span class='ohm-browserKeywordHighlights' style='"+colorOhm+" !important;cursor: pointer !important'>$2</span>$3");
				while (temp.firstChild) {
					textNode.parentNode.insertBefore(temp.firstChild, textNode);
				}
				textNode.parentNode.removeChild(textNode);
				
				checkAppendNode = true;
			} 
		}
	} else {
		checkAppendNode = false;
		var temp = document.createElement('div');
		var text = decodeHtml(" "+textNode.data+" "); 
		
		if (text.indexOf('<meta') == -1) {
			if (typeof clOhm == "undefined")
				colorOhm = "color:#FF171F";
			temp.innerHTML = text.replace(exp,"$1<span class='ohm-browserKeywordHighlights' style='"+colorOhm+" !important;cursor: pointer !important'>$2</span>$3");
			while (temp.firstChild) {
				textNode.parentNode.insertBefore(temp.firstChild, textNode);
			}
			textNode.parentNode.removeChild(textNode);
			
			checkAppendNode = true;
		} 
	}
}
function qualifyURL(url){
    var img = document.createElement('img');
    img.src = url; // set string url
    url = img.src; // get qualified url
    img.src = null; // no server request
    return url;
}
var kohm = 0;

// chon OTA khi chua dong nhap
function loadKeyword(select) {	
	var OHMdomain = document.domain;
	console.log('load keyword khi chua dang nhap');
	// kiem tra domain OHM.vn 
	if(OHMdomain.search("ohm.vn")===-1){
		checkNumberShowKeyword = {};
		if (typeof $("#ohm-style").attr("id") != 'undefined') {
			$("#ohm-style").remove();
		}
		console.log('kiem tra dang nhap: chua dong nhap');
		$("body").append('<style id="ohm-style">.ohm-browserLinkHighlights:before{z-index:9999999;content: "";background: url(https://ads.ohm.vn/images/dtohm.png) left top no-repeat;background-size: cover;width: 16px;height: 16px;margin-left: -12px;margin-top: -5px;float:left;text-indent:0;}.ohm-browserKeywordHighlights{overflow:visible!important;font-size: inherit !important;width:auto!important;height:auto!important;float:none!important;margin:0!important;padding:0!important;left:0!important;top:0!important;right:0!important;bottom:0!important;border:none!important;display:inline!important;box-shadow:none!important;text-decoration:none!important;position:static!important;cursor:pointer!important;background:0 0!important;opacity: initial !important;}#ohm-browserTooltip{width:300px!important;z-index:9999999999!important;background:#1788DB!important;position:absolute!important;border:1px solid #fff!important;box-shadow:0 0 10px #1788DB!important}#ohm-browserTooltip *{line-height:20px!important;height:auto!important;background:0 0!important;font-size:13px!important;float:none!important;opacity:1!important;visibility:visible!important;color:#fff!important;margin:0!important;padding:0!important;border:none!important;font-weight:400!important;font-style:normal!important;letter-spacing:normal!important;font-family:arial!important;display:block!important;box-shadow:none!important;text-indent:inherit!important;text-decoration:none!important;cursor:pointer!important;position:static!important}#ohm-browserTooltip .ohm-gotourl{white-space:nowrap!important;position:relative!important;border-bottom:1px solid rgba(255,255,255,.17)!important;padding:10px 65px 10px 10px!important}#ohm-browserTooltip .ohm-gotourl:hover{background:#287CBA!important}#ohm-browserTooltip .ohm-disabled *{color:rgba(255,255,255,.46)!important}#ohm-browserTooltip.ohm-browserLink .ohm-disabled{color:rgba(255,255,255,.46)!important}#ohm-browserTooltip .ohm-disabled:hover,#ohm-browserTooltip .ohm-disabled:hover *{cursor:no-drop!important}#ohm-browserTooltip .ohm-gotourl .ohm-keyword{overflow:hidden!important;text-overflow:ellipsis!important;text-align:left!important}#ohm-browserTooltip .ohm-gotourl .ohm-plusota{position:absolute!important;right:10px!important;top:9px!important}#ohm-browserTooltip .ohm-gotourl .ohm-plusota img{width:15px!important;height:15px!important;vertical-align:middle!important;position:relative!important;top:-1px!important;margin:0 0 0 3px!important;display:inline-block!important}#ohm-browserTooltip .ohm-browserTooltipBtnWrap{text-align:right!important;}#ohm-browserTooltip .ohm-browserTooltipBtn{padding:16px!important;text-transform:uppercase!important;display:inline-block!important;font-weight:500!important;}#ohm-browserTooltip #infoOhm{padding:10px 10px 0!important;line-height:20px!important;font-size:13px!important;} #ohm-browserTooltip.ohm-browserLink {max-width: 90px !important;width:auto!important;}   #ohm-browserTooltip .ohm-linkText {    text-align: center !important;    padding: 10px !important;    line-height: 100% !important;   }   #ohm-browserTooltip .ohm-linkText img {    width: 15px!important;    height: 15px!important;    vertical-align: middle!important;    position: relative!important;    top: -1px!important;    margin: 0 0 0 3px!important;    display: inline-block!important;   }</style>');
		
		var Buffer = require('buffer').Buffer
		var LZ4 = require('lz4')
		
		if (typeof select == 'undefined') {
			var str =$("html").html();
		} else {
			var str =$(select).text();
		}
		
		
		if (str.length < 100) {
			str += " "+str+" ";
			str += " "+str+" ";
			str += " "+str+" ";
		} else if (str.length < 200) {
			str += " "+str+" ";
		}
		
		var input = new Buffer(str)
		var output = new Buffer( LZ4.encodeBound(input.length) )
	
		var compressedSize = LZ4.encodeBlock(input, output)
		// remove unnecessary bytes
		output = output.slice(0, compressedSize);
	
		$.ajax({
			url : urlOhm+"keyword-no-login?length="+input.length+"&p="+pubId+"&t=json"+"&url="+encodeURIComponent(location.href),
			//dataType: 'jsonp',
			method : "PUT",
			processData: false,
			contentType: 'application/octet-stream',
	//		contentType: "application/json",
			//jsonpCallback: 'jsonCallbackOhm',
			data: output,
			success : function(result) {	
				console.log("complete");
				//console.log(result);
	
				var obj = $.parseJSON(result) ; 
				var selector = obj.selector; 
				var text = $(selector).html();
				var domain = window.location.host;
				
				if (typeof obj.username != 'undefined') {
					statusLoginOhm = 'true';
				}
		
				if(statusLoginOhm == "true") {	
					$("#avatarOhm").html("<img style='border-radius:30px;-moz-border-radius:30px;-webkit-border-radius:30px;border:3px solid while;' src='"+obj.avatar+"'>");
					$("#usernameOhm").html("<a href='http://account.ohm.vn/userinfo' target='_blank'>"+obj.username+"</a>");
				}
			
				if (statusLoginOhm == "true") {
	    			$.each( obj.url, function( key, val ) {
	    				var keys = key;
	    				
	    			  	$('body a').each(function() {
	    			  		var hr = qualifyURL ($(this).attr("href"));
	    			  		//console.log(key);
	    			  		if ( typeof $(this).attr("href") !== "undefined" && key.toLowerCase() == hr.toLowerCase() ) {
	    			  			
	//    			  			if ($(this).find(".tooltip-hint-ohm").length <=0 ) {
	    			  				
	    			  				$(this).attr("onclick","return gotoota(\""+val[0].url+"\", this.id, "+val[0].ota+", \""+keys.toLowerCase()+"\",\"currentTab\")");
	    			  				$(this).attr("data", val[0].ota);
	    			  				$(this).attr("cid", val[0].cId);
	//    			  				$(this).html("<span style='background: url(\""+urlOhm+"/images/ota2.png\") no-repeat !important;' class='ota-ohm tooltip-hint-ohm' data='"+val[0].ota+" OTA'>&nbsp;</span>"+$(this).html());
	    			  				$(this).addClass("ohm-browserLinkHighlights");
	//    			  			}
	    			  		}
						});
	    			});
				}
				//console.log('chon vao keyword khi chua dang nhap!');
				var ohmSortKey = sortObject(obj.keyword);
				console.log(obj);
				var keySave;
				
				if (typeof select == 'undefined') {
					var objectOHM = $(selector);
				} else {
					var objectOHM = $(select);
				}
				if (objectOHM.length <= 0) {
					objectOHM = $('body');
				}
				
				objectOHM.each(function() {
					var abc = this;
					$.each( ohmSortKey, function( key, val ) {
						var ohmValue = "";
						var valohm = val.length;
						keySave = key;
						$.each( val, function( key, val ) {
							ohmValue = ohmValue +"<span class='tooltip-oat-ohm-text' title='"+val.name+"'><span data="+val.cId+" id='ohmblock"+kohm+"' class='ohm-gotourl' onclick='return gotoota(\""+val.url+"\", this.id, "+val.ota+", \""+keySave.toLowerCase()+"\", \"newTab\");' ><span class='ohm-keyword'> "+val.name+"</span> <span class='ohm-plusota'>+ "+val.ota+" <img src='"+urlOhm+"images/dtohm.png' /></span></span></span>";
							kohm++;
		    			}); 
						ohmObj[$.trim(key)] = ohmValue;
						
						var pattern = "([\(\)\"“”.,?:;!#$%\t\n\v\f\r\) ]{1})("+key+")([\(\)\"“”.,?:;!#$%\t\n\v\f\r\) ]{1})";
						
						guessLanguage.info(key, function(info) {
						    //console.log('Detected Language: ' + info[2] + " [" + info[0] + "]");
						    if (info[0] == "zh" || info[0] == "ja" || info[0] == "ko") {
						    	pattern = "([\(\)\"“”.,?:;!#$%\t\n\v\f\r\) ]{0,1})("+key+")([\(\)\"“”.,?:;!#$%\t\n\v\f\r\) ]{0,1})";
						    }
						});
						
						if (numberShowKeyword != 100)
							var exps = new RegExp(pattern, "");
						else
							var exps = new RegExp(pattern, "g");
						traverseChildNodes(abc, exps);
					});
				});
							
				ohmToolTip (); 
			},
			error: function () {
				console.log("error");
			},
			beforeSend: function( xhr ) {
				console.log("start");
				xhr.overrideMimeType( "text/plain; charset=utf-8" );
			}
		});
	}
}

function gotoota(url, obj, ota, keyword, tab){
	if(tab == "currentTab") {
		if ($("#"+obj).hasClass("ohm-disabled") == false) {
			chrome.runtime.sendMessage({action: "objClick", data: $("#"+obj).attr("data")}, function(response) {
	  		    //console.log(response.farewell);
	  		});
	  		window.location = url;	
		}	
	} else {
		if ($("#"+obj).hasClass("ohm-disabled") == false) {
			chrome.runtime.sendMessage({action: "objClick", data: $("#"+obj).attr("data")}, function(response) {
	  		    //console.log(response.farewell);
	  		});
	  		var tab=window.open(url,'_blank'); 
			tab.focus();
		}	
	}
	$("#ohm-browserTooltip").css("display", "none");
	
	return false;
}

function locations(url) {
	window.location = url+"?continue="+encodeURIComponent(location.href);
	return false;
}

function reload(){
	window.location = location.href;
}

function setCookie(cname,cvalue,exdays) {
    var d = new Date();
    d.setTime(d.getTime() + exdays);
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname+"="+cvalue+"; "+expires+"; domain="+document.domain+"; path=/";
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function eraseCookie (name,path,domain) {
	if (getCookie(name)) {
		document.cookie = name + "=" +
		((path == null) ? "" : "; path=" + path) +
		((domain == null) ? "" : "; domain=" + domain) +
		"; expires=Thu, 01-Jan-70 00:00:01 GMT";
	}
}


function getParameterByName(name) {
	if (document.referrer.indexOf(loginOHM) != -1 || document.referrer.indexOf(registerOHM) != -1) {
	    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
	    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),   
	        results = regex.exec(document.referrer);
	    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
	}
	
	return "";
}

function logout(info) {
	eraseCookie(nameOhm, "/", document.domain);
	$("#ohm_exit").remove();
	history.pushState(null, "title 1", "");

	$.ajax({
		url : logoutohm,
		dataType: 'jsonp',
		contentType: "application/json",
		jsonpCallback: 'jsonCallbackOhm',
		success : function(result) {	
			if (result.logoutohm == "success") {
				if(info != "noinfo")
					setCookie("logout", "true", 20000);
				window.location=location.href;
			}
		},
		beforeSend: function( xhr ) {
			xhr.overrideMimeType( "text/plain; charset=utf-8" );
		}
	});
}

function changeColor() {
	if (getCookie(nameCheckOhm)=="off") {
		setCookie(nameCheckOhm, "on", 30*24*60*60*1000);
		$(".slideOhm").css('left','24px');
		$(".ohm-browserKeywordHighlights").css("color","#"+clOhm);
		$("#onOhm").css("background-color", "#26788C");
	} else {
		setCookie(nameCheckOhm, "off", 30*24*60*60*1000);
		$(".slideOhm").css('left','2px');
		$(".ohm-browserKeywordHighlights").css("color","");
		$("#onOhm").css("background-color", "red");
	}
}

function rgb2hex(rgb) {
    if (  rgb.search("rgb") == -1 ) {
         return rgb.replace("#","");
    } else {
    	rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    	return "" +
    	("0" + parseInt(rgb[1],10).toString(16)).slice(-2) +
    	("0" + parseInt(rgb[2],10).toString(16)).slice(-2) +
    	("0" + parseInt(rgb[3],10).toString(16)).slice(-2);
    }
}

function changeColorFromPicker(vthis) {
	clOhm = rgb2hex(vthis.style.backgroundColor);
	setCookie(nameColorOhm, clOhm, 30*24*60*60*1000);	
	if (getCookie(nameCheckOhm)=="on") {
		$(".ohm-browserKeywordHighlights").css("color","#"+clOhm);
		$(".ohmcolor").css("background","#"+clOhm);
	} else {
		$(".ohmcolor").css("background","#"+clOhm);
	}
}

function toolbarOhm() {
	$("#toolbar-ohm").toggle();
}

function openPicker() {
	$(".colorTableOhm").toggle();
}

function checkCookie() {
	if(getCookie(nameCheckOhm)=="") {
		setCookie(nameCheckOhm, "on", 30*24*60*60*1000);
	}
	
	if (getCookie(nameColorOhm) != "") {
		clOhm = getCookie(nameColorOhm);
	} else {
		setCookie(nameColorOhm, "FF171F", 30*24*60*60*1000);
		clOhm = "FF171F";
	}
	
	if (getCookie(nameCheckOhm) == "off") {
		colorOhm = "";
	} else {
		colorOhm = "color:#"+clOhm;
	}
	
	var a = getParameterByName("a");

	if (a != "") {
		setCookie(nameOhm, "login", 30*24*60*60*1000);
		history.pushState(null, "title 1", "");
		
		setTimeout(function(){ 
			$("body").append("<div id='ohm-popup'>"+languageOhm.infoLogin+"</div>");
		}, 1000);		
		
		setTimeout(function(){ 
			$("#ohm-popup").remove();
		}, 5000);	
	}
	
	loadKeyword();
	
	if (getCookie("logout") != "") {	
		setTimeout(function(){ 
			$("body").append("<div id='ohm-popup'>"+languageOhm.infoLogout +"</div>");
		}, 1000);		
		
		setTimeout(function(){ 
			$("#ohm-popup").remove();
		}, 5000);
		eraseCookie("logout", "/", document.domain);
	}	
	if (getCookie(nameColorOhm) != "")
		clOhm = getCookie(nameColorOhm);
	
}

function isIE () {
	var myNav = navigator.userAgent.toLowerCase();
	return (myNav.indexOf('msie') != -1) ? parseInt(myNav.split('msie')[1]) : false;
}


function ohmToolTip () {
	var ohmKey; 
	var timeouts = [];
	var ohmTimeout;

	$("body").append("<div id='ohm-browserTooltip' class='ohm-browserLink' style='display:none;'></div>");
	
	$( ".ohm-browserKeywordHighlights" )
    	.mouseenter(function(event) {
    		$("#ohm-browserTooltip").removeClass("ohm-browserLink");
    		
    		var ohmOffset = $(this).offset();  		
    		
    		var leftThis = ohmOffset.left;
    		var topThis = ohmOffset.top;    		
    		
    		ohmKey = $.trim($(this).text());
    		
    		if ($("#ohm-browserTooltip").html() != ohmObj[ohmKey]) {
    			if (statusLoginOhm == "true") {
    				var html = ohmObj[ohmKey]; 
    				
    				if(objRemove) {
    					$.each(objRemove, function(key, val){
	    					html = html.replace("ohm"+val, "ohm-disabled ohm-hidden");
	    				});
    				}
    				
    				$("#ohm-browserTooltip").html( html );
    				
    				var cHid = $(".ohm-otherAdv").find(".tooltip-oat-ohm-text").length;
    				
    				for(i=0;i<cHid;i++) {
    					var counts = $(".ohm-hightlightAdv").find(".tooltip-oat-ohm-text").find(".ohm-gotourl:not(.ohm-hidden)").length;
    	
    					var objClone = $(".ohm-viewport_inner .tooltip-oat-ohm-text").eq(i).clone();
    					if (objClone.find(".ohm-hidden").length <= 0 && counts < 3) {
    						
    						$(".ohm-hightlightAdv").append(objClone);
        					$(".ohm-viewport_inner .tooltip-oat-ohm-text").eq(i).find(".ohm-gotourl").addClass("ohm-hidden");
    					}
    				}
    				
    				if ($(".ohm-hightlightAdv").find(".tooltip-oat-ohm-text").find(".ohm-gotourl:not(.ohm-hidden)").length < 3 || 
    						$(".ohm-otherAdv .tooltip-oat-ohm-text").find(".ohm-gotourl:not(.ohm-hidden)").length <= 0) {
    					$(".ohm-showMore").addClass("ohm-hidden");
    				}
    				
    				$(".ohm-arrowUp").click(function(){
    					var countOtherAdv = $(".ohm-otherAdv .tooltip-oat-ohm-text").find(".ohm-gotourl:not(.ohm-hidden)").length;
    					if (countOtherAdv > 3) {
    						$(".ohm-viewport_inner").css("cssText", "margin-top: 0 !important");
    					}
    				});
    				$(".ohm-arrowDown").click(function(){
    					var countOtherAdv = $(".ohm-otherAdv .tooltip-oat-ohm-text").find(".ohm-gotourl:not(.ohm-hidden)").length;
    					if (countOtherAdv > 3) {
    						$(".ohm-viewport_inner").css("cssText", "margin-top: -123px !important");
    					}
    				});
    				
    				$(".ohm-showMore").click(function(){
    					$(this).addClass("ohm-hidden");
    					$(".ohm-otherAdv").removeClass("ohm-hidden");
    				});
    				$(".ohm-viewport_inner .tooltip-oat-ohm-text").hover (
						function() {
							$(this).children(".ohm-advDesc").css("cssText", "top:" + ($(this).offset().top + $(this).height()-$("#ohm-browserTooltip").offset().top-1) + "px !important");
						}
					);
    			} else {
    				$("#ohm-browserTooltip").html( ohmRegister );
    			}
    		} 
    		
    		var ohmLeft = leftThis - ($("#ohm-browserTooltip").width()/2) + ($(this).width()/2);
    		
    		if (leftThis < $("#ohm-browserTooltip").width()/2) {
    			ohmLeft = 0;
    		}
    		
    		if ( (leftThis + $("#ohm-browserTooltip").width() ) > $(document).width()) {
    			ohmLeft = $(document).width() - $("#ohm-browserTooltip").width() - 30;
    		}
    		
    		var ohmTop = topThis - ($("#ohm-browserTooltip").height()) - $(this).height() + 5;
    		
    		if ((ohmTop - $(document).scrollTop()) < 0) {
    			ohmTop = topThis + 20;
    		}
    		
    		for (var i = 0; i <= timeouts.length; i++) {
    		    clearTimeout(timeouts[i]);
    		}
    		timeouts = [];
    		
    		if (event.pageX < ohmLeft || event.pageX > (ohmLeft+$("#ohm-browserTooltip").width())) {
    			ohmLeft = event.pageX - $("#ohm-browserTooltip").width()/2;
    			ohmTop = event.pageY - $("#ohm-browserTooltip").height()-30;
    			
    			if ( (ohmLeft + $("#ohm-browserTooltip").width() ) > $(window).width()) {
        			ohmLeft = $(window).width() - $("#ohm-browserTooltip").width() - 30;
        		}
    		}
    		
    		$("#ohm-browserTooltip").css('left', ohmLeft + 'px');
    		$("#ohm-browserTooltip").css('top', ohmTop + 'px');
    		if ($(".ohm-hightlightAdv").find(".tooltip-oat-ohm-text").find(".ohm-gotourl:not(.ohm-hidden)").length == 0) {
    			if (statusLoginOhm == "true") {
    				$(this).contents().unwrap();
    				$("#ohm-browserTooltip").css("display", "none");
    			} else {
    				$("#ohm-browserTooltip").css('display', 'block');
    			}
			} else {
				$("#ohm-browserTooltip").css('display', 'block');
			}
    	})

    	.mouseleave(function() {
    		timeouts.push(setTimeout(function(){ $("#ohm-browserTooltip").css('display', 'none'); }, 300));
		});
	
	$( ".ohm-browserKeywordHighlights" ).click(function(){
		if($("#ohm-browserTooltip").css("display")=='block') {
			$("#ohm-browserTooltip").css("display",'none');
		}
	});
	
	
	//link
	$( ".ohm-browserLinkHighlights" )
		.mouseenter(function(event) {
			$("#ohm-browserTooltip").addClass("ohm-browserLink");
			
			var ohmOffset = $(this).offset();  		
			
			var leftThis = ohmOffset.left;
			var topThis = ohmOffset.top;    		
	
			ohmKey = $(this).text().toLowerCase();
			if ($("#ohm-browserTooltip").html() != ohmObj[ohmKey]) {
				var classLink = '';
				if (statusLoginOhm == "true") {
					console.log(objRemove);
					var cidLink = $(this).attr("cid");
					if(objRemove.length > 0) {
    					$.each(objRemove, function(key, val){
	    					if(cidLink == val){
	    						classLink = "ohm-disabled";
	    					} else {
	    						classLink = "ohm"+cidLink;
	    					}
	    				});
    				} else {
    					classLink = "ohm"+cidLink;
    				}
					var html = "<span data='"+$(this).attr("cid")+"' class='ohm-linkText "+classLink+"' id='ohmblock"+kohm+"'  onclick='"+$(this).attr("onclick")+"'>"+'+ '+$(this).attr("data")+ '<img src=\"https://ads.ohm.vn/images/dtohm.png\" />' +"</span>";					
					kohm++;
					$("#ohm-browserTooltip").html( html );
					
				} else {
					$("#ohm-browserTooltip").html( ohmRegister );
				}
			} 
			
			var ohmLeft = leftThis - ($("#ohm-browserTooltip").width()/2) + ($(this).width()/2);
			
			if (leftThis < $("#ohm-browserTooltip").width()/2) {
				ohmLeft = 0;
			}
			
			if ( (leftThis + $("#ohm-browserTooltip").width() ) > $(document).width()) {
				ohmLeft = $(document).width() - $("#ohm-browserTooltip").width() - 30;
			}
			
			var ohmTop = topThis - ($("#ohm-browserTooltip").height()) - $(this).height() + 5;
			
			if ((ohmTop - $(document).scrollTop()) < 0) {
				ohmTop = topThis + 20;
			}
			
			for (var i = 0; i <= timeouts.length; i++) {
			    clearTimeout(timeouts[i]);
			}
			timeouts = [];
			
			if (event.pageX < ohmLeft || event.pageX > (ohmLeft+$("#ohm-browserTooltip").width())) {
				ohmLeft = event.pageX - $("#ohm-browserTooltip").width()/2;
				ohmTop = event.pageY - $("#ohm-browserTooltip").height()-30;
				ohmTop = Math.abs(ohmTop);
				if ( (ohmLeft + $("#ohm-browserTooltip").width() ) > $(window).width()) {
	    			ohmLeft = $(window).width() - $("#ohm-browserTooltip").width() - 30;
	    		}
			}
			
			$("#ohm-browserTooltip").css('left', ohmLeft + 'px');
			$("#ohm-browserTooltip").css('top', ohmTop + 'px');
			$("#ohm-browserTooltip").css('display', 'block');
		})
	
		.mouseleave(function() {
			timeouts.push(setTimeout(function(){ $("#ohm-browserTooltip").css('display', 'none'); }, 300));
		});
	
	$( ".ohm-browserLinkHighlights" ).click(function(){
		if($("#ohm-browserTooltip").css("display")=='block') {
			$("#ohm-browserTooltip").css("display",'none');
		}
	});
	
	
	
	
	$("#ohm-browserTooltip")
		.mouseenter(function() {
			for (var i = 0; i <= timeouts.length; i++) {
    		    clearTimeout(timeouts[i]);
    		}
			timeouts = [];

		})
		.mousemove(function(){
			for (var i = 0; i <= timeouts.length; i++) {
    		    clearTimeout(timeouts[i]);
    		}
			timeouts = [];
			
			$("#ohm-browserTooltip").css('display', 'block');	        		
    	})
		.mouseleave(function() {
    		timeouts.push(setTimeout(function(){ $("#ohm-browserTooltip").css('display', 'none'); }, 300));
		});
}

$(document).ready(function(){
	
	$(".sfsbc").click (function (){
		 chrome.storage.sync.get({
       	  	OHMdisable: 'no',
       	  	color:"#FF171F",
       	  	numberShowKeyword : 1
       	}, function(items) { 
       	    if( items.OHMdisable !='yes'  ){ 
       	    	//loadKeyword();
       	    	chrome.runtime.sendMessage({action: "keyword", content: $("body").html(), url: location.href}, function(response) {
       	  		    //console.log(response.farewell);
       	  		});
       		}
       	});
	});
	
	//start chat facebook
	var numberChat = 0;

	var myVar = setInterval(function(){ 

		if (typeof $(".conversation").attr('class') != 'undefined') {	
			  
			  if (numberChat != $(".conversation").length) {
//				  setTimeout (function(){
					  var flength = {}; 
					  var flastText = {};
					  
					  $(".conversation").each(function( index ) {
						  $(".conversation:eq("+index+")").unbind( "DOMNodeInserted DOMNodeRemoved" );
					  });
					  numberChat = $(".conversation").length;
					  
					  $(".conversation").each(function( index ) {
						  flength[index] = $(".conversation:eq("+index+")").find(".direction_ltr").length;
						  flastText[index] = $.trim($(".conversation:eq("+index+") .direction_ltr:last-child").text());
						  console.log(numberChat);
						  $(".conversation:eq("+index+")").bind("DOMNodeInserted DOMNodeRemoved",function(){
							  
							  if ($.trim($(".conversation:eq("+index+") .direction_ltr:last-child").text()) != flastText[index] && checkAppendNode) {
								  
								  //console.log("text: "+$(".conversation:eq("+index+") .direction_ltr:last-child").text());
								  
								  $(function(){
										 chrome.storage.sync.get({
								       	  	OHMdisable: 'no',
								       	  	color:"#FF171F",
								       	  	numberShowKeyword : 1
								       	}, function(items) { 
								       	    if( items.OHMdisable !='yes'  ){ 
//								       	    	loadKeyword(".conversation:eq("+index +") .direction_ltr:last-child");
								       	    	var select = ".conversation:eq("+index +") .direction_ltr:last-child";
								       	    	chrome.runtime.sendMessage({action: "keyword", content: $(select).text(), url: location.href, select: select}, function(response) {
								       	  		    //console.log(response.farewell);
								       	  		});
								       		}
								       	});
								  });
								  
								  flength[index] = $(".conversation:eq("+index+")").find(".direction_ltr").length;
								  flastText[index] = $.trim($(".conversation:eq("+index+") .direction_ltr:last-child").text());
							  }
						  });
					  });
//				  }, 5000);				  
			  }
//			  clearInterval(myVar);
		} else {
			numberChat = 0;
		}
	}, 1000);
	
	//end chat facebook

});
