
//chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab){
//    if(changeInfo && changeInfo.status == "loading"){
//
//        chrome.tabs.sendMessage(tabId, {data: tab, action: "changeUrl"}, function(response) {
//
//        });
//    }
//
//});
//chrome.tabs.onActivated.addListener(function(activeInfo) {
//	  chrome.tabs.sendMessage(activeInfo.tabId, {data: activeInfo.tabId, action: "changeUrl"}, function(response) {
//
//      });
//});
chrome.extension.onMessage.addListener(
    function(message, sender, sendResponse) {
        if ( message.type == 'getTabId' )
        {
            sendResponse({ tabId: sender.tab.id });
        }
    }
);

var idBrowser = new Date().getTime();
var ohmObjRemove = [];
var listOnSite = [];

/* start lay thong tin cua user  */
var bname = "";
var bId = 0;
var fname = "";
var bavatar = "";
var bfullName = "";
var bnumMessage = 0;
//
var bota1 = 0;
var bota2 = 0;
var bota3 = 0;
var tokenkeyohm;
var lockPrize = false;
var totalPrice = 0;
var totalDate = 0;
var totalName = "";
var totalMoney = 0;
// setting sound
var soundStatus = 'on';

// lang nghe su kien mo tab moi de lay id tab do


chrome.tabs.onCreated.addListener(function(tab){
    setTimeout(function(){
		   chrome.tabs.executeScript(tab.id, {file: "js/abs.js"} );
		   chrome.tabs.insertCSS(tab.id, {file: "css/styleabs.css"} );
		   chrome.tabs.insertCSS(tab.id, {file: "css/view.css"} );
    }, 2000);
    console.log("inject  thanh cong!");
});



// remove tabs after create new tab



/*
chrome.tabs.query({
    active: true,               // Select active tabs
    lastFocusedWindow: true     // In the current window
}, function(array_of_Tabs) {
    // Since there can only be one active tab in one active window,
    //  the array has only one element
    var tab = array_of_Tabs[0];
    // Example:
    var url = tab.url;
    // ... do something with url variable
});*/

// gui noi dung trinh duyet web len abs server
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action == "keyword") {
    	var str = request.content;

    	if (str.length < 100) {
    		str += " "+str+" ";
    		str += " "+str+" ";
    		str += " "+str+" ";
    	} else if (str.length < 200) {
    		str += " "+str+" ";
    	}

		var Buffer = require('buffer').Buffer
    	var LZ4 = require('lz4')
    	var input = new Buffer(str)
		var output = new Buffer( LZ4.encodeBound(input.length) )

		var compressedSize = LZ4.encodeBlock(input, output)
		// remove unnecessary bytes
		output = output.slice(0, compressedSize);
    	var pubId = 5668411803697152;
    	// gui yeu cau len Abs sever de nhan key work
    	$.ajax({
    		url : "http://ads.ohaymaha.com/keyword-chanel?length="+input.length+"&p="+pubId+"&t=json&tabId="+sender.tab.id+"&idBrowser="+idBrowser+"&select="+request.select+"&url="+encodeURIComponent(request.url),
    		//dataType: 'jsonp',
    		method : "POST",
    		processData: false,
    		contentType: 'application/octet-stream',
//    	    		contentType: "application/json",
    		//jsonpCallback: 'jsonCallbackOhm',
    		data: output,
    		success : function(result) {
    			console.log("complete");

    		},
    		error: function () {
    			console.log("error");
    		},
    		beforeSend: function( xhr ) {
    			console.log("start");
    			xhr.overrideMimeType( "text/plain; charset=utf-8" );
    		}
    	});

    }
    // hanh dong click tu khoa
    if (request.action == "objClick") {
    	ohmObjRemove.push(request.data);
    	chrome.tabs.getAllInWindow(null, function(tabs){
    		console.log(ohmObjRemove+"remove");
    		console.log("da click vao tu khoa");
	    	for (var i = 0; i < tabs.length; i++) {
		    	chrome.tabs.sendMessage(tabs[i].id, {action: 'objRemove', eltObj: ohmObjRemove}, function(response) {
		        });
		    }
		});
    }


    if (request.action == "onunloadPage") {
    	if(listOnSite.length > 0) {
    		for (var key in listOnSite) {
    			if(key == request.id) {
    				var value = listOnSite[key];
    				var timeOnsSite = (request.time - value.time)/1;
    				if (timeOnsSite != 0) {
	    				$.ajax({
						    type: "GET",
						    url: "https://ads.ohaymaha.com/save-time-on-url?time="+timeOnsSite+"&userId="+bId+"&url="+encodeURIComponent(value.url)+"&doc="+value.time,
						    success:function(data) {
						    	console.log(data);
						    },
						    error: function () {
						    	console.log("error");
						    }
	    				});
    				}

    				delete listOnSite[key]
    			}
			}
			listOnSite[request.id] = {url:request.url, time:request.time};
    	} else {
    		listOnSite[request.id] = {url:request.url, time:request.time};
    	}
    	console.log(listOnSite);
    }
});

function actionLoadingPage(tabId, url, time) {

}



/*
 	* doi mau nen chu on tren icon extension
*/
chrome.storage.sync.get({
		OHMdisable: 'no'
	}, function(keyitems) {
		if( keyitems.OHMdisable =='yes'  ){
			chrome.browserAction.setBadgeText({text: "off"});
			chrome.browserAction.setBadgeBackgroundColor({ color: '#cccccc' });
		} else {
			chrome.browserAction.setBadgeText({text: "on"});
			chrome.browserAction.setBadgeBackgroundColor({ color: '#1FD002' });
		}
	}
);
/*
*	lay thong tin nguoi dung
*/

function getInfoUser () {
	chrome.cookies.get ({'url': "http://www.ohaymaha.com/",'name':'__ohmt__'}, function (cookies) {

		if (cookies !=null) {
		    tokenkeyohm = cookies.value;
		} else {
			$.ajax({
			    url: 'https://ads.ohaymaha.com/logout',
			    type: 'GET',
			    success: function(response){
			    	console.log(response);
					chrome.browserAction.setIcon({path: "../img/ohm-off.png"}, function (){});
			    }
			 });
		}

		if (chrome.extension.lastError) {
			$.ajax({
			    url: 'https://ads.ohaymaha.com/logout',
			    type: 'GET',
			    success: function(response){
			    	console.log(response);
			   	}
			 });
		}

		if( typeof tokenkeyohm != 'undefined' && tokenkeyohm != ''){
			$.ajax({
				url : 'http://userv2.api.ohaymaha.com/me',
				type : "POST",
				headers : {
					'E8668OHM' : tokenkeyohm,
				},
				dataType : 'json',
				async : false,
				statusCode: {
				    403: function() {
				      	$.ajax({
						    url: 'https://ads.ohaymaha.com/logout',
						    type: 'GET',
						    success: function(response){
						    	console.log(response);
						    	location.reload();
						  	chrome.tabs.reload();
						    }
						 });
				    }
				},
				success : function(response) {
					console.log(response);
					if( response.state == 2  ){
					       	$.ajax({
						    url: 'https://ads.ohaymaha.com/logout',
						    type: 'GET',
						    success: function(response){
						    	console.log(response);
						    	location.reload();
						  		chrome.tabs.reload();
						    }
						});
					}

					var user = response.user;
					console.log(user);
					bname = user.userName;
					bId = user.userId;
					bavatar = user.avatar;
					bfullName = user.fullName;
					chrome.storage.sync.set({'statusLoginOhm': "true"}, function() {});
				}
			});

			$.ajax({
				url : 'http://user.api.ohaymaha.com/ota/notainbag',
				type : "POST",
				headers : {
					'E8668OHM' : tokenkeyohm,
				},
				dataType : 'json',
				async : false,
				statusCode: {
				    403: function() {
				      	 $.ajax({
					    url: 'https://ads.ohaymaha.com/logout',
					    type: 'GET',
					    success: function(response){
					    	location.reload();
					  		chrome.tabs.reload();
					    }
					 });
				    }
				},
				success : function(response) {
					console.log(response);
					var obj = response.accounting;
					lockPrize = obj.lockPrize;
					bota1 = obj.tsOTAprize;
					bota2 = obj.tsOTAstore;
					bota3 = obj.tsOTAdeal;
				}
			});
			var obj1 = {};
			obj1.type = 1;

			$.ajax({
				url : 'http://v2.user-api.ohaymaha.com/gettotalprize',
				type : "POST",
				headers : {
					'E8668OHM' : tokenkeyohm,
				},
				dataType : 'json',
				data: JSON.stringify(obj1),
				async : false,
				statusCode: {
				    403: function() {
				      	 $.ajax({
					    url: 'https://ads.ohaymaha.com/logout',
					    type: 'GET',
					    success: function(response){
					    	location.reload();
					  		chrome.tabs.reload();
					    }
					 });
				    }
				},
				success : function(response) {
					totalPrice = response.awards.prize;
					totalDate = response.awards.date;
					totalName = response.awards.name;
					totalMoney = response.awards.money;
				}
			});
		}
	});
}


getInfoUser();

var checkLogin = 0;

//bat su kien load page
chrome.tabs.onUpdated.addListener( function (tabId, changeInfo, tab) {

	chrome.cookies.get ({'url': "http://www.ohaymaha.com/",'name':'__ohmt__'}, function (cookies) {
		var tokenkeyohm;
		if (cookies !=null)
		    tokenkeyohm = cookies.value;

		//neu chua dang nhap hien anh offline
		if( typeof tokenkeyohm == 'undefined'){
			console.log("log out hien anh offline");
			chrome.browserAction.setIcon({path: "../img/ohm-off.png"}, function (){});
			checkLogin = 1; //bien khoi tao chua co token
			//Kien tra
			/*
			 * mau nen mac dinh cua mot o trong setting
			 */
			chrome.storage.sync.get({
					OHMdisable: 'no'
				}, function(keyitems) {
					if( keyitems.OHMdisable =='yes'  ){
						chrome.browserAction.setBadgeText({text: "off"});
						chrome.browserAction.setBadgeBackgroundColor({ color: '#cccccc' });
					} else {
						chrome.browserAction.setBadgeText({text: "on"});
						chrome.browserAction.setBadgeBackgroundColor({ color: '#1FD002' });
					}
				}
			);
			chrome.storage.sync.set({'statusLoginOhm': 'false'}, function() {});
		} else {
			//neu dang nhap
			if (checkLogin == 1) {
				console.log("Login");
				checkLogin = 0;
		    	var arRemove = [];
		    	//neu login bang account khac, reload lai background
				var background = chrome.extension.getBackgroundPage();
				background.location.reload();

    	    	//gui message cho content_script thay doi noi dung keyword
    	    	chrome.tabs.getAllInWindow(null, function(tabs){
				    for (var i = 0; i < tabs.length; i++) {
				    	chrome.tabs.sendMessage(tabs[i].id, {action: 'login'}, function(response) {
				            //console.log(i);
				        });
				    }
				});

    	    	chrome.storage.sync.set({'statusLoginOhm': 'true'}, function() {});
			}
			/*
			*	neu dang nhap thi  hien anh online
			*
			*/
			chrome.browserAction.setIcon({path: "../img/icon28.png"}, function (){

			});
			if (count != 0) {
				chrome.browserAction.setBadgeText({text: ""+count+""});
				//chrome.browserAction.setBadgeBackgroundColor({ color: '#1FD002' });
			}
			console.log("Gui thong tin den tat ca cac trang");
			chrome.tabs.getAllInWindow(null, function(tabs){
		    	for (var i = 0; i < tabs.length; i++) {
		    		console.log("tabs["+i+"].url = "+tabs[i].url);
			    	chrome.tabs.sendMessage(tabs[i].id, {action: 'objRemove', eltObj: arRemove}, function(response) {
			        });
			    }
			});
		}

	});
})




chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.method == "getToken")
      sendResponse({token: localStorage['tokenkeyohm']});
    else
      sendResponse({}); // snub them.
});
