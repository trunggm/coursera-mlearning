/**
 * Extension OHM v 1.0
 *
 * @author    Vu Duc Chinh <chinhvuduc2014 at gmail dot com>
 */
 var globaltotalPrize;
 var temp;
 var temp0;
 var temp1;
 var temp2;
 var seconds = 1;
 var seconds1 = 1;
 var tokenkeyohm;
 var temptotalOTA;
 var userOTA;
 var userOTAS;
 var temp3;
 var conutNotify;
 var currentAvatar;
 var currentfullName;



$(document).ready(function(){


	// open / close dropdown action
	$(".ohm-exDropdown").click(function(){
		$(".ohm-exDropdownAction").toggle();
	});

	globaltotalPrize = chrome.extension.getBackgroundPage().totalPrice;
	console.log(globaltotalPrize);
	temp = document.getElementById("totalPrice");
	temp.innerHTML = $.number(globaltotalPrize);
	console.log(temp.innerHTML);

	var dateTT = new Date(chrome.extension.getBackgroundPage().totalDate);

	$("#totalDate").html(dateTT.getMonth()+1+"/"+dateTT.getDate()+"/"+dateTT.getFullYear());
	$("#totalName").html("$"+chrome.extension.getBackgroundPage().totalName);
	$("#totalMoney").html("$"+$.number(chrome.extension.getBackgroundPage().totalMoney));

	// hien thi thanh lua chon
	if(chrome.extension.getBackgroundPage().colorPick==0){
		$('#keywordspick').addClass('ohm-btpick');
		$('#linkspick').addClass('ohm-pointer');
		$('.ohm-exKeywordColor').removeClass("hidden");
		$('.ohm-exLinkColor').addClass("hidden");
	}
	else{
		$('#linkspick').addClass('ohm-btpick');
		$('#keywordspick').addClass('ohm-pointer');
		$('.ohm-exKeywordColor').addClass("hidden");
		$('.ohm-exLinkColor').removeClass("hidden");
	}

	// ham tu dong update

	function countdown() {
		if(seconds>1){
			chrome.cookies.get ({'url': "http://www.ohaymaha.com/",'name':'__ohmt__'}, function (cookies) {
			    tokenkeyohm = cookies.value;
			});
			if( typeof tokenkeyohm != 'undefined' && tokenkeyohm != ''){
				  //globaltotalPrize = $.number(chrome.extension.getBackgroundPage().totalPrice)+1;
				  			var obj1 = {};
							obj1.type = 1;
				  			$.ajax({
								url : 'http://v2.user-api.ohaymaha.com/gettotalprize',
								type : "POST",
								headers : {
									'E8668OHM' : tokenkeyohm,
								},
								dataType : 'json',
								data: JSON.stringify(obj1),
								async : false,
								success : function(response) {
									chrome.extension.getBackgroundPage().totalPrice = response.awards.prize;
									globaltotalPrize = response.awards.prize;
									console.log(globaltotalPrize);
								}
							});
			 }
			temp0 = document.getElementById('totalPrice');
			console.log(seconds + " " + globaltotalPrize);
		  	temp0.innerHTML = $.number(globaltotalPrize);
		  	console.log(temp0.innerHTML);
		}
		else{
			temp0 = document.getElementById('totalPrice');
		  	console.log(temp0.innerHTML);
		}
		seconds += 1;

	 	timeoutMyOswego = setTimeout(countdown, 20000);
	}

	countdown();

// tu dong cap nhan so ota cua nguoi dung
	function countdownOTA(){
	if(seconds1 > 1){
		userOTAS = parseInt(chrome.extension.getBackgroundPage().bota2);
		userOTA = parseInt(chrome.extension.getBackgroundPage().bota1), 10;

		temp1 = document.getElementById('countota1');
		temp2 = document.getElementById('countota2');
		temp4 = document.getElementById('totalPrice');
		var numberToltalOTA = (temp4.innerHTML).replace(',','');
		var tempuserOTA = parseInt(temp1.innerHTML, 10);
	  	temptotalOTA = parseInt(numberToltalOTA, 10);

	  	temptotalOTA += userOTA - tempuserOTA;

	  	temp1.innerHTML = userOTA;
	  	temp2.innerHTML = userOTAS;
	  	temp4.innerHTML = $.number(temptotalOTA);

	  	// auto hien thi so tin nhan
	  	conutNotify = chrome.extension.getBackgroundPage().count;
	  	if  (conutNotify > 0) {

			$("#notify span").addClass('count-notify');
			$("#notify span").text(chrome.extension.getBackgroundPage().count);
		}
		else{
			$("#notify span").removeClass('count-notify');
			$("#notify span").empty();
		}
		// auto update avatar

		currentAvatar = document.getElementById('info_avatar').src;
		var nextAvatar = chrome.extension.getBackgroundPage().bavatar;
		console.log(nextAvatar + " vs " + currentAvatar);
		if(currentAvatar != nextAvatar){
			$('#info_avatar').removeAttr("src");
			$('#info_avatar').attr("src", nextAvatar);
		}

		// auto update full name
		var fullname = document.getElementById('info_fullname');
		currentfullName = fullname.innerHTML;
		var nextfullName = chrome.extension.getBackgroundPage().bfullName;
		if(currentfullName != nextfullName){
			fullname.innerHTML = nextfullName;
		}
	};
	  	seconds1 += 1;
	 	timeoutMyOswego = setTimeout(countdownOTA, 1500);
	};

	countdownOTA();



	function dhm(t){
	    var cd = 24 * 60 * 60 * 1000;
	    var ch = 60 * 60 * 1000;
	    var sh = 60 * 1000;
	    var d = Math.floor(t / cd);
	    var h = "0" + Math.floor( (t - d * cd) / ch);
	    var m = "0" + Math.round( (t - d * cd - h * ch) / sh);
	    var	s = "0" + (Math.round( (t - d * cd - h * ch - m * sh) / 1000)+30);
	    return d+" <span class='text'>days</span> "+h.substr(-2)+":"+m.substr(-2)+":"+s.substr(-2);
	}
	setInterval(function(){
		var dt = new Date();
		var delay = dateTT.getTime() - dt.getTime();
		if (delay > 0) {
			var fullTime = dhm(delay);
			$("#countdown").html(fullTime);
		} else {
			$("#countdown").html("");
		}
	}, 1000);

	// navtab
	$(".ohm-exOptions li a").click(function() {
		$(".ohm-exOptions li").removeClass("active");
		$(".ohm-exOptionsDetail > div").addClass("hidden");
		$(this).parents("li").addClass("active");
		var id = $(this).attr("href");
		$(id).removeClass("hidden");
	});

	$('.userinfo').click(function(){
	 	chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
			var url = tabs[0].url;
			chrome.tabs.update( null, { url: "http://account.ohaymaha.com/#/account" , selected: true} );
		  	window.close();
		});
	});
	$('.listota').click(function(){
	 	chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
			var url = tabs[0].url;
			chrome.tabs.update( null, { url: "http://account.ohaymaha.com/#/list-ota" , selected: true} );
		  	window.close();
		});
	});
	$('#listnotify').click(function(){
	 	chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
			var url = tabs[0].url;
			chrome.tabs.update( null, { url: "http://account.ohaymaha.com/#/notification" , selected: true} );
		  	window.close();
		});
	});
	/*
	 * doi mau dc chon tren thanh key color chon so luong key
	 *
	 */
	chrome.storage.sync.get({
	    OHMdisable: 'no',
	    color:"#FF171F",
	    linkcolor:"#1CC56F",
	    numberShowKeyword :100 // bat gia tri show keywords
	}, function(keyitems) {
		$(".showKeyword").each(function(){
			if ($(this).val() == keyitems.numberShowKeyword) {
				$(this).attr("checked", true);
			}
		});


		if( keyitems.OHMdisable !='yes' ){
			$('.vohieu').show();
			$('.kichhoat').hide();
			$('.ohm-exKeyColorSelected').css('background', keyitems.color);
			$('.ohm-exLinkColorSelected').css('background', keyitems.linkcolor);
		}
		else
		{
			$('.vohieu').hide();
			$('.kichhoat').show();
			$('.ohm-exKeyColorSelected').css('background', keyitems.color);
		}
	});

	$('.vohieu').click(function(){
		vohieu();
		var tokenkeyohm;
		chrome.cookies.get ({'url': "http://www.ohaymaha.com/",'name':'__ohmt__'}, function (cookies) {
			if (cookies !=null)
			    tokenkeyohm = cookies.value;
		});
		chrome.tabs.getAllInWindow(null, function(tabs){
		    for (var i = 0; i < tabs.length; i++) {
		    	chrome.tabs.sendMessage(tabs[i].id, {status: "off", action: 'changeStatus', token: tokenkeyohm}, function(response) {
		            //console.log(i);
		        });
		    }
		});

	});
	$('.kichhoat').click(function(){
		kichhoat();
		var tokenkeyohm;
		chrome.cookies.get ({'url': "http://www.ohaymaha.com/",'name':'__ohmt__'}, function (cookies) {
			if (cookies !=null)
			    tokenkeyohm = cookies.value;

		});
		chrome.tabs.getAllInWindow(null, function(tabs){
		    for (var i = 0; i < tabs.length; i++) {
		    	chrome.tabs.sendMessage(tabs[i].id, {status: "on", action: 'changeStatus', token: tokenkeyohm}, function(response) {
		            //console.log(i);
		        });
		    }
		});

	});

	$(".showKeyword").click(function () {
		chrome.storage.sync.set({'numberShowKeyword': $(this).val()}, function() {
	    	chrome.tabs.getAllInWindow(null, function(tabs){
			    for (var i = 0; i < tabs.length; i++) {
			    	chrome.tabs.sendMessage(tabs[i].id, {action: 'numberShowKeyword'}, function(response) {
			            //console.log(i);
			        });
			    }
			});
	  	});
	});

	$('#btnlogin').click(function(){
	 	chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
			var url = tabs[0].url;
			chrome.tabs.update( null, { url: "http://www.ohaymaha.com/login?continue="+encodeURIComponent(url) , selected: true} );
		  	window.close();
		});
	});
	$('#btnregister').click(function(){
		chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
			var url = tabs[0].url;
			chrome.tabs.update( null, { url: "http://account.ohaymaha.com/register?continue="+url , selected: true} );
		  	window.close();
		});
	});
	$('.ohm-sExtension').click(function(){
		window.create({url: "https://chrome.google.com/webstore/detail/ota-glass/hnfhkoglifghiefamgnfkkojdpggkaec"}, 'blank');
	});
	$('.ohm-sPublisher').click(function(){
		window.create({url: "http://publisher.ohaymaha.com/info"}, 'blank');
	});
	$('.ohm-sAllocator').click(function(){
		window.create({url: "http://oad.ohaymaha.com/"}, 'blank');
	});
	$('.ohm-sUser').click(function(){
		window.create({url: "http://account.ohaymaha.com/"}, 'blank');
	});
	$('.ohm-sOhm').click(function(){
		window.create({url: "http://www.ohaymaha.com/"}, 'blank');
	});

	if(chrome.extension.getBackgroundPage().soundStatus =='on'){
		$('.vohieusound').show();
		$('.kichhoatsound').hide();
	}
	else{
		$('.vohieusound').hide();
		$('.kichhoat').show();
	}
	// khi click vao sound seting
	$('.vohieusound').click(function(){
		vohieusound();
	});
	$('.kichhoatsound').click(function(){
		kichhoatsound();
	});

	$('#keywordspick').click(function(){
		if(chrome.extension.getBackgroundPage().colorPick==1){
			console.log("pick");
			$('#keywordspick').addClass("ohm-btpick");
			$('#linkspick').removeClass("ohm-btpick");
			$('#keywordspick').removeClass("ohm-pointer");
			$('#linkspick').addClass("ohm-pointer");
			$('.ohm-exKeywordColor').removeClass("hidden");
			$('.ohm-exLinkColor').addClass("hidden");
			chrome.extension.getBackgroundPage().colorPick = 0;
		}
	});

	$('#linkspick').click(function(){
		if(chrome.extension.getBackgroundPage().colorPick==0){
			$('#keywordspick').removeClass("ohm-btpick");
			$('#linkspick').addClass("ohm-btpick");
			$('#keywordspick').addClass("ohm-pointer");
			$('#linkspick').removeClass("ohm-pointer");
			$('.ohm-exKeywordColor').addClass("hidden");
			$('.ohm-exLinkColor').removeClass("hidden");
			chrome.extension.getBackgroundPage().colorPick = 1;
		}
	});
});

// cap nhat ota lien tuc
	//var temp = document.getElementById("totalPrice");
	//temp.innerHTML = $.number(chrome.extension.getBackgroundPage().totalPrice;

var tokenkeyohm;


chrome.cookies.get ({'url': "http://www.ohaymaha.com/",'name':'__ohmt__'}, function (cookies) {
	if (cookies !=null)
	    tokenkeyohm = cookies.value;
	//kiem tra neu tokenKey da ton tai
	if( typeof tokenkeyohm != 'undefined' && tokenkeyohm != ''){
		var obj1 = {};
		obj1.type = 1;
		$.ajax({
			url : 'http://v2.user-api.ohaymaha.com/gettotalprize',
			type : "POST",
			headers : {
				'E8668OHM' : tokenkeyohm,
			},
			dataType : 'json',
			data: JSON.stringify(obj1),
			async : false,
			statusCode: {
			    403: function() {
			      	 $.ajax({
				    url: 'https://ads.ohaymaha.com/logout',
				    type: 'GET',
				    success: function(response){
				    	location.reload();
				  		chrome.tabs.reload();
				    }
				 });
			    }
			},
			success : function(response) {
				chrome.extension.getBackgroundPage().totalPrice = response.awards.prize;
				chrome.extension.getBackgroundPage().totalDate = response.awards.date;
				chrome.extension.getBackgroundPage().totalName = response.awards.name;
				chrome.extension.getBackgroundPage().totalMoney = response.awards.money;
			}
		});
		$("#refress").click(function(){
			$(".ohm-exActiveSectionMaskItem").removeClass("hidden");
			$(".ohm-exOtaType").addClass("hidden");
			$(".ohm-exListNotification").addClass("hidden");
			$.ajax({
				url : 'http://user.api.ohaymaha.com/ota/notainbag',
				type : "POST",
				headers : {
					'E8668OHM' : tokenkeyohm,
				},
				dataType : 'json',
				async : false,
				statusCode: {
				    403: function() {
				      	 $.ajax({
					    url: 'https://ads.ohaymaha.com/logout',
					    type: 'GET',
					    success: function(response){
					    	location.reload();
					  		chrome.tabs.reload();
					    }
					 });
				    }
				},
				success : function(response) {
					console.log(response);
					var obj = response.accounting;

					$('#countota1').html($.number(obj.tsOTAprize));
					$('#countota2').html($.number(obj.tsOTAstore));
					$('#countota3').html($.number(obj.tsOTAdeal));

					chrome.extension.getBackgroundPage().bota1 = obj.tsOTAprize;
					chrome.extension.getBackgroundPage().bota2 = obj.tsOTAstore;
					chrome.extension.getBackgroundPage().bota3 = obj.tsOTAdeal;

					setTimeout(function(){
						$(".ohm-exOtaType").removeClass("hidden");
						$(".ohm-exListNotification").removeClass("hidden");
						$(".ohm-exActiveSectionMaskItem").addClass("hidden");
					},1000);
				}
			});
		});

		//hien thi ota cua cac ngan
		$('#countota1').html($.number(chrome.extension.getBackgroundPage().bota1));
		$('#countota2').html($.number(chrome.extension.getBackgroundPage().bota2));
		$('#countota3').html($.number(chrome.extension.getBackgroundPage().bota3));


		$('.ohm-exNotLoggedIn').addClass('hidden');
		$('.ohm-exLoggedIn').removeClass('hidden');

		//show thong tin user
		$('#info_avatar').attr("src", chrome.extension.getBackgroundPage().bavatar);
		$('#info_name').html(chrome.extension.getBackgroundPage().bname);
		$('#info_fullname').html(chrome.extension.getBackgroundPage().bfullName);

		//show thong tin ota

		$('#btnlogout').click(function(){
			 $.ajax({
			    url: 'https://ads.ohaymaha.com/logout',
			    type: 'GET',
			    success: function(response){

	    	    	//gui message cho content_script thay doi mau sac
	    	    	chrome.tabs.getAllInWindow(null, function(tabs){
					    for (var i = 0; i < tabs.length; i++) {
					    	chrome.tabs.sendMessage(tabs[i].id, {action: 'logout'}, function(response) {
					            //console.log(i);
					        });
					    }
					});

	    	    	//neu login bang account khac, reload lai background
					var background = chrome.extension.getBackgroundPage();
					background.location.reload();

			    	chrome.browserAction.setIcon({path: "../img/ohm-off.png"}, function (){});

					//Kien tra
					chrome.storage.sync.get({
							OHMdisable: 'no'
						}, function(keyitems) {
							if( keyitems.OHMdisable =='yes'  ){
								chrome.browserAction.setBadgeText({text: "off"});
								chrome.browserAction.setBadgeBackgroundColor({ color: '#cccccc' });
							} else {
								chrome.browserAction.setBadgeText({text: "on"});
								chrome.browserAction.setBadgeBackgroundColor({ color: '#1FD002' });
							}
						}
					);

					//xoa cookie channel cua trang publisher khi logout
					chrome.cookies.getAll({},function (cookie){
				        console.log(cookie.length);
				        for(i=0;i<cookie.length;i++){
				            var ck = cookie[i];
				            if (ck.name == "channel") {
				            	console.log(location.href);
				            	chrome.cookies.remove({ 'url': "http" + (ck.secure ? "s" : "") + "://" + ck.domain + ck.path, 'name': ck.name });
				            }
				        }
				    });

			    	$('.ohm-exLoggedIn').addClass('hidden');
					$('.ohm-exNotLoggedIn').removeClass('hidden');
					$('html').addClass('ohm-exIntro');
			    }
			 });
		});


	} else {
		//neu chua co tokenKey

		$('.ohm-exNotLoggedIn').removeClass('hidden');
		$('.ohm-exLoggedIn').addClass('hidden');
		$('html').addClass('ohm-exIntro');
	}
});

if  (chrome.extension.getBackgroundPage().count > 0) {
//	$("#info").html("( "+chrome.extension.getBackgroundPage().count+" )");
	// $("#notify span").css('background', '#FFFF92');
	$("#notify span").addClass('count-notify');
	$("#notify span").text(chrome.extension.getBackgroundPage().count);
}
if  (chrome.extension.getBackgroundPage().lockPrize  == true) {
	if($('#ohm-exTotalOta .ohm-exOtaType > div:first-child .title').hasClass("lock") == false) {
		$('#ohm-exTotalOta .ohm-exOtaType > div:first-child .title').addClass("lock");
	}
} else {
	if($('#ohm-exTotalOta .ohm-exOtaType > div:first-child .title').hasClass("lock") == true) {
		$('#ohm-exTotalOta .ohm-exOtaType > div:first-child .title').removeClass("lock");
	}
}

//xem notify
$("#notify").click(function(){
//	$('#loading').html('<img src="'+chrome.extension.getURL('img/load.gif')+'"/>');
//	$("#loading").css("display", "block");
//	$(".OHMuserpanel").css("display", "none");
	$(".ohm-exListNotification").addClass("hidden");
	$("#ohm-exNotification .ohm-exActiveSectionMaskItem").removeClass("hidden");
	var notify = "https://user-api.ohaymaha.com/listnotify";
	var tokenKey;
	chrome.cookies.get ({'url': "http://www.ohaymaha.com/",'name':'__ohmt__'}, function (cookies) {
		if (cookies != null) {
			tokenKey = cookies.value;
		}

		var obj = {page:1, row: 10};

		$.ajax({
			    type: "POST",
			    dataType: "json",
			    url: notify,
			    timeout: 10000,
			    data: JSON.stringify(obj),
			    headers: {
			    	'E8668OHM' : tokenKey
			    },
			    success:function(data) {
			    	console.log (data);
			    	var obj = data;
			    	if (obj.state == "Ok") {
					var str = "";
					var list = obj.list;



					$.each( list, function( key, val ) {
						var date = new Date(val.time);
						var  m = date.getMinutes() < 9?"0"+date.getMinutes():date.getMinutes();
						var mo = (date.getMonth()+1) < 9?"0"+(date.getMonth()+1):(date.getMonth()+1);
						str += "<div class=\"ohm-exNotificationItem\" id='"+val.id+"'> <img src='"+val.avatar+"' alt=\"\"> <h4 class=\"title\">"+val.title+"</h4> <p class=\"text\">"+
						date.getHours()+":"+m+" "+date.getDate()+"/"+mo+"/"+date.getFullYear()+"</p> </div>";
					});
					console.log(str);
					$(".ohm-exLatestNotification").html(str);
					$(".ohm-exListNotification").removeClass("hidden");
					$("#ohm-exNotification .ohm-exActiveSectionMaskItem").addClass("hidden");

					$("#notify span").text('');
					$("#notify span").removeClass('count-notify');
					// show / hide notification
					$(".ohm-exNotificationToolbar").click(function(){
						$(".ohm-exNotificationDetail").removeClass("active");
					});

					$(".ohm-exNotificationItem").click(function(){
						$(".ohm-exNotificationDetail").addClass("active");

						$(".ohm-exListNotification").addClass("hidden");
						$("#ohm-exNotification .ohm-exActiveSectionMaskItem").removeClass("hidden");

						var objDetail = {id:$(this).attr("id")};

						$.ajax({
							    type: "POST",
							    dataType: "json",
							    url: "https://user-api.ohaymaha.com/detailsnotify",
							    data: JSON.stringify(objDetail),
							    headers: {
							    	'E8668OHM' : tokenKey
							    },
							    success:function(data) {
							    	var obj = data;
							    	console.log(obj);
							    	if (obj.state == "Ok") {
							    		var list = obj.notification;
							    		var date = new Date(list.time);
							    		$("#d_notify_title").html(list.title)
							    		var  m = date.getMinutes() < 9?"0"+date.getMinutes():date.getMinutes();
							    		var mo = (date.getMonth()+1) < 9?"0"+(date.getMonth()+1):(date.getMonth()+1);
							    		$("#d_notify_time").html(date.getHours()+":"+m+" "+date.getDate()+"/"+mo+"/"+date.getFullYear());
							    		$("#d_notify_detail").html(list.details.replace(/\[\"/g, "").replace(/\"\]/g, "").replace(/\", \"/g, " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; "));

							    		$(".ohm-exListNotification").removeClass("hidden");
										$("#ohm-exNotification .ohm-exActiveSectionMaskItem").addClass("hidden");
							    	}
							    },
							    error: function () {
							    	console.log("Connection to "+notify+" error");
							    }
						});
					});

					//xoa toan bo notify khi nguoi dung click vao 1 message
					chrome.notifications.getAll(function (obj) {
						$.each(obj, function(key, value){
							chrome.notifications.clear(key, function (){});
						});
					});

					//reset bien dem message
					chrome.extension.getBackgroundPage().count = 0;
					$("#info").html(chrome.extension.getBackgroundPage().count);
					//Kien tra login logout doi mau chu on - off
					chrome.storage.sync.get({
							OHMdisable: 'no'
						}, function(keyitems) {
							if( keyitems.OHMdisable =='yes'  ){
								chrome.browserAction.setBadgeText({text: "off"});
								chrome.browserAction.setBadgeBackgroundColor({ color: '#cccccc' });
							} else {
								chrome.browserAction.setBadgeText({text: "on"});
								chrome.browserAction.setBadgeBackgroundColor({ color: '#1FD002' });
							}
						}
					);
				}
			    },
			    error: function () {
			    	console.log("Connection to "+notify+" error");
			    }
		});
	});
});
//////// change key color
var keycl;
$(".change_keycolor li").click(function(){
	keycl = "#"+rgb2hex($(this).css("background-color"));
	$('.ohm-exKeyColorSelected').css('background', keycl);
	chrome.storage.sync.set({'color': "#"+rgb2hex($(this).css("background-color"))}, function() {
		//gui thong tin logout ra toan bo tab
    	chrome.storage.sync.get({
    	  	OHMdisable: 'no',
    	  	color:"#FF171F"
    	}, function(keyitems) {
    	    if( keyitems.OHMdisable !='yes'  ){
    	    	//gui message cho content_script thay doi mau sac
    	    	chrome.tabs.getAllInWindow(null, function(tabs){
				    for (var i = 0; i < tabs.length; i++) {
				    	chrome.tabs.sendMessage(tabs[i].id, {color: keycl, action: 'changeKeyColor'}, function(response) {
				            //console.log(i);
				        });
				    }
				});

    		} else {

    		}
    	});
  	});
});
/*
 * doi mau link
 *
 */
var linkcl;
$(".change_linkcolor li").click(function(){ // khi click vao mau sac o thank mau sac
	linkcl = "#"+rgb2hex($(this).css("background-color")); // gan bien linkcl bang mau sach cua mau dc chon
	$('.ohm-exLinkColorSelected').css('background', linkcl); // them truoong background vs mau sac duoc chon vao class ohm-exLinkColorSelected

	chrome.storage.sync.set({'linkcolor': "#"+rgb2hex($(this).css("background-color"))}, function() {
		//gui thong tin logout ra toan bo tab

    	chrome.storage.sync.get({
    	  	OHMdisable: 'no',
    	  	linkcolor:"#FF171F"
    	}, function(linkitems) {
    	    if( linkitems.OHMdisable !='yes'  ){
    	    	//gui message cho content_script thay doi mau sac
    	    	chrome.tabs.getAllInWindow(null, function(tabs){
				    for (var i = 0; i < tabs.length; i++) {
				    	chrome.tabs.sendMessage(tabs[i].id, {color: linkcl, action: 'changeLinkColor'}, function(response) {
				    		 //console.log("Change Link color");
				        });
				    }
				});

    		} else {

    		}
    	});
  	});
});

function rgb2hex(rgb) {
    if (  rgb.search("rgb") == -1 ) {
         return rgb.replace("#","");
    } else {
    	rgb = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    	return "" +
    	("0" + parseInt(rgb[1],10).toString(16)).slice(-2) +
    	("0" + parseInt(rgb[2],10).toString(16)).slice(-2) +
    	("0" + parseInt(rgb[3],10).toString(16)).slice(-2);
    }
}
function vohieu() {
	chrome.storage.sync.set({'OHMdisable': 'yes'}, function() {
          // Notify that we saved.
    	});
	$('.vohieu').hide();
	$('.kichhoat').show();
	if(chrome.extension.getBackgroundPage().bnumMessage == 0){
		chrome.browserAction.setBadgeText({text: "off"});
	}
	chrome.browserAction.setBadgeBackgroundColor({ color: '#cccccc' });
}
function kichhoat() {
	chrome.storage.sync.set({'OHMdisable': 'no'}, function() {
          	// Notify that we saved.
    });

	$('.kichhoat').hide();
	$('.vohieu').show();
	if(chrome.extension.getBackgroundPage().bnumMessage == 0){
		chrome.browserAction.setBadgeText({text: "on"});
	}
	chrome.browserAction.setBadgeBackgroundColor({ color: '#1FD002' });
}

/*
*	sound seting function
*/
function vohieusound() {
	$('.vohieusound').hide();
	$('.kichhoatsound').show();
	chrome.extension.getBackgroundPage().soundStatus = 'off';
	console.log(chrome.extension.getBackgroundPage().soundStatus);
}
function kichhoatsound() {
	$('.kichhoatsound').hide();
	$('.vohieusound').show();
	chrome.extension.getBackgroundPage().soundStatus = 'on';
	console.log(chrome.extension.getBackgroundPage().soundStatus);
}
function reload_c_tab(){
	chrome.tabs.reload();
	window.close();
}

// goi countdown
//countdown();
