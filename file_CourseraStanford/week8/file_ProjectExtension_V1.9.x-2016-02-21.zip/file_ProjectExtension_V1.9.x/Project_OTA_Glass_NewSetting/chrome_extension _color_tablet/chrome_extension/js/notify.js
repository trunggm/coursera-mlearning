//if (typeof jQuery == 'undefined') {
//	openChannel(tokenChannel);
//} else {
//	$(document).ready(function () {
//		openChannel(tokenChannel);
//	});
//}

/*
 * Tao chanel ngay khi tao
 */
initNotificationOHM = function (tokenKey) {
	var tokenUrl = "https://www.ohaymaha.com/api/createChannel";

	$.ajax({
		type: "POST",
	    dataType: "json",
	    url: tokenUrl,
	    headers: {
	    	'E8668OHM' : tokenKey
	    },
	    success:function(data) {
	    	var obj = data;
	    	console.log("create successed!");
	    	if (obj.state == "Ok") {
	    		console.log(obj.tokenChannel);
	    		openChannel(obj.tokenChannel);
	    	} else {
	    		console.log("Can't access tokenChannel");
	    	}
	    },
	    error: function () {
	    	console.log("Connection to " + tokenUrl + " error");
	    }
	});
}

initNotificationOHM_refresh = function (refreshKey) {
	var tokenUrl_refresh = "http://user-api.ohaymaha.com/getAccessToken";

	var dataSend = {};
	dataSend.refreshToken = refreshKey
	$.ajax({
		type: "POST",
	    dataType: "json",
	    url: tokenUrl_refresh,
	    data:  JSON.stringify(dataSend),
	    success:function(data) {
	    	var obj = data.token;
	    	console.log(obj);
	    	console.log("create successed!");
	    	if (data.state == "Ok") {

	    		console.log("refreshKey: " + obj.refreshKey);
	    		initNotificationOHM(obj.tokenKey);
	    		return;
	    	} else {
	    		console.log("Can't access tokenChannel");
	    		return;
	    	}
	    },
	    error: function () {
	    	console.log("Connection to " + tokenUrl_refresh + " error");
	    }
	});
}

openChannel = function(tokenChannel) {
	channel = new goog.appengine.Channel(tokenChannel);
	socket = channel.open();
	socket.onopen = onSocketOpen;
	socket.onmessage = onSocketMessage;
	socket.onerror = onSocketError;
	socket.onclose = onSocketClose;
};

closeChannel = function () {
	console.log('channel da tụ đọng close');
	socket.close();
}

onSocketError = function(error){
	console.log('channel error');
	console.log("Error is "+error.description+" and HTML code"+error.code);
	NotificationOHM.onerror();
};

onSocketOpen = function() {
	console.log("Open soccket Success.");

	chrome.tabs.getAllInWindow(null, function(tabs){
	    for (var i = 0; i < tabs.length; i++) {
	    	chrome.tabs.sendMessage(tabs[i].id, {action: 'socket'}, function(response) {
	            //console.log(i);
	        });
	    }
	});
};

onSocketClose = function() {
	console.log("Socket Connection closed");
	NotificationOHM.onclose();
};

onSocketMessage = function (response) {
	console.log("Notify Message New");
	console.log(response);

	var data = {};
	var obj = JSON.parse(response.data);

	if (obj.type == 1) {
		NotificationOHM.notifyOTA(obj.data);
	} else if (obj.type == 3) {
		NotificationOHM.notifyChatMessage(obj.data);
	} else if (obj.type == 4) {
		NotificationOHM.notifyUserTransaction(obj.data);
	} else if (obj.type == 5) {
		NotificationOHM.notifyUserGetOTA(obj.data);
	} else if (obj.type == 6) {
		NotificationOHM.notifyUserGetKeyword(obj.data);
	} else if (obj.type == 7) {
		NotificationOHM.notifyUserChangeInfor(obj.data);
	} else if (obj.type == 10) {
		NotificationOHM.notifyDeleteNumberNotify(obj.data);
	} else if (obj.type == 20) {
		NotificationOHM.notifyLock(obj.data);
	} else if (obj.type == 999) {
		NotificationOHM.notifySystem(obj.data);
	}
};

var NotificationOHM = {
	onerror : function () {},
	onclose : function () {},
	notifyOTA : function (data) {},
	notifyChatMessage : function (data) {},
	notifyUserTransaction: function (data) {},
	notifyUserChangeInfor: function (data) {},
	notifyUserGetOTA: function (data) {},
	notifyUserGetKeyword: function (data) {},
	notifyDeleteNumberNotify: function (data) {},
	notifyLock: function (data) {},
	notifySystem: function (data) {}
};
